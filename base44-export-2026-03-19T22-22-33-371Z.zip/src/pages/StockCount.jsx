const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ClipboardList, PackagePlus, CheckCircle2, AlertTriangle, Search } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { openWhatsAppNotification } from "@/utils/whatsapp";
import { usePermissions } from "@/components/auth/usePermissions";

// ─── Contagem Tab ───────────────────────────────────────────────────────────

function ContagemTab({ products, stores, settings }) {
  const queryClient = useQueryClient();
  const { user } = usePermissions();
  const [storeFilter, setStoreFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [counts, setCounts] = useState({}); // { [productId]: { boxes, extra_units, quantity } }
  const [saving, setSaving] = useState(false);

  const activeStores = useMemo(() => stores.filter(s => s.active !== false), [stores]);

  const selectedStore = useMemo(() => {
    if (storeFilter === "all") return null;
    return activeStores.find(s => String(s.id) === String(storeFilter)) || null;
  }, [storeFilter, activeStores]);

  const selectedStoreTypes = useMemo(() => {
    if (!selectedStore) return null;
    if (selectedStore.kitchen_types?.length > 0) return selectedStore.kitchen_types;
    if (selectedStore.kitchen_type) return [selectedStore.kitchen_type];
    return null;
  }, [selectedStore]);

  // Todos os tipos de cozinha conhecidos (para identificar produtos "universais")
  const allKnownKitchenTypes = useMemo(() => {
    return [...new Set(stores.flatMap(s => s.kitchen_types || []))].map(t => t.toLowerCase());
  }, [stores]);

  const productMatchesStore = (p) => {
    if (!selectedStoreTypes) return true;
    const storeTypesLower = selectedStoreTypes.map(t => t.toLowerCase());
    const productKitchenTypes = p.kitchen_types || [];

    if (productKitchenTypes.length > 0) {
      // Produto tem kitchen_types definidos: usa eles
      return productKitchenTypes.some(t => storeTypesLower.includes(t.toLowerCase()));
    }

    // Produto sem kitchen_types: usa a category para identificar
    const cat = (p.category || "").toLowerCase();
    const matchedKitchen = allKnownKitchenTypes.find(kt => kt.includes(cat) || cat.includes(kt));
    if (matchedKitchen) {
      // Produto pertence a uma cozinha específica — filtra
      return storeTypesLower.some(kt => kt.includes(cat) || cat.includes(kt));
    }
    // Produto universal (categoria não mapeia nenhuma cozinha) — aparece em todas
    return true;
  };

  const filtered = useMemo(() => {
    return products.filter(p => {
      if (p.status !== "ativo") return false;
      if (search && !p.name?.toLowerCase().includes(search.toLowerCase())) return false;
      return productMatchesStore(p);
    });
  }, [products, search, selectedStoreTypes, allKnownKitchenTypes]);

  const updateCount = (product, field, value) => {
    setCounts(prev => {
      const current = prev[product.id] || { boxes: "", extra_units: "", quantity: "" };
      const updated = { ...current, [field]: value };

      if (product.has_box_counting) {
        const boxes = Number(updated.boxes) || 0;
        const extra = Number(updated.extra_units) || 0;
        updated.quantity = boxes * (product.units_per_box || 1) + extra;
      } else {
        updated.quantity = value;
      }

      return { ...prev, [product.id]: updated };
    });
  };

  const getCount = (productId) => counts[productId] || null;

  const changedProducts = filtered.filter(p => {
    const c = getCount(p.id);
    if (!c) return false;
    const qty = Number(c.quantity);
    return !isNaN(qty) && qty !== p.quantity;
  });

  const handleSalvar = async () => {
    if (changedProducts.length === 0) {
      toast.info("Nenhuma alteração para salvar.");
      return;
    }

    setSaving(true);
    const today = format(new Date(), "yyyy-MM-dd");

    try {
      for (const product of changedProducts) {
        const c = getCount(product.id);
        const newQty = Number(c.quantity);
        const diff = newQty - (product.quantity || 0);

        await db.entities.StockMovement.create({
          product_id: product.id,
          product_name: product.name,
          type: "ajuste",
          quantity: newQty,
          movement_date: today,
          reason: `Contagem de estoque — ajuste de ${product.quantity || 0} → ${newQty} (${diff >= 0 ? "+" : ""}${diff})`,
        });

        await db.entities.Product.update(product.id, { quantity: newQty });
      }

      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["movements"] });

      const details = changedProducts.map(p => {
        const c = getCount(p.id);
        return `• ${p.name}: ${p.quantity || 0} → ${Number(c.quantity)}`;
      }).join("\n");

      openWhatsAppNotification({
        whatsappNumber: settings?.whatsapp_number,
        userName: user?.full_name || user?.email || "Funcionário",
        action: `Contagem de estoque (${changedProducts.length} produto(s))`,
        details,
      });

      setCounts({});
      toast.success(`Contagem salva! ${changedProducts.length} produto(s) atualizado(s).`);
    } catch (e) {
      toast.error("Erro ao salvar contagem.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header info */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-xl p-4">
        <p className="text-sm text-blue-700 dark:text-blue-300 font-medium">
          📋 Preencha a quantidade atual de cada produto. Ao salvar, o estoque será atualizado automaticamente.
        </p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Buscar produto..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        {activeStores.length > 0 && (
          <Select value={storeFilter} onValueChange={v => { setStoreFilter(v); setCounts({}); }}>
            <SelectTrigger className="w-full sm:w-52">
              <SelectValue placeholder="Filtrar por loja" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as lojas</SelectItem>
              {activeStores.map(s => (
                <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Product list */}
      <div className="space-y-2">
        {filtered.length === 0 && (
          <p className="text-center text-slate-400 py-10">Nenhum produto encontrado.</p>
        )}
        {filtered.map(product => {
          const c = getCount(product.id);
          const countedQty = c ? Number(c.quantity) : null;
          const diff = countedQty !== null ? countedQty - (product.quantity || 0) : null;
          const isLow = product.quantity <= (product.min_quantity || 0);

          return (
            <div key={product.id} className={cn(
              "bg-white dark:bg-slate-800 border rounded-xl p-4 space-y-3 transition-all",
              c ? "border-blue-300 dark:border-blue-600 shadow-sm" : "border-slate-200 dark:border-slate-700"
            )}>
              {/* Product info */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <p className="font-semibold text-slate-800 dark:text-slate-100">{product.name}</p>
                  <div className="flex items-center gap-2 mt-1 flex-wrap">
                    <span className="text-xs text-slate-400">Estoque atual: <span className={cn("font-bold", isLow ? "text-red-500" : "text-slate-700 dark:text-slate-200")}>{product.quantity || 0} {product.unit || ""}</span></span>
                    {isLow && <Badge variant="outline" className="text-xs border-red-200 text-red-600 bg-red-50"><AlertTriangle className="w-3 h-3 mr-1" />Baixo</Badge>}
                    {product.category && <Badge variant="outline" className="text-xs">{product.category}</Badge>}
                  </div>
                </div>
                {diff !== null && (
                  <div className={cn("text-right text-sm font-bold", diff > 0 ? "text-emerald-600" : diff < 0 ? "text-red-500" : "text-slate-400")}>
                    {diff > 0 ? `+${diff}` : diff === 0 ? "=" : diff}
                  </div>
                )}
              </div>

              {/* Counting input */}
              {product.has_box_counting ? (
                <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-lg p-3 space-y-2">
                  <p className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                    1 {product.box_unit_label || "caixa"} = {product.units_per_box || 1} {product.unit || "unidade"}(s)
                  </p>
                  <div className="flex gap-3">
                    <div className="flex-1 space-y-1">
                      <label className="text-xs text-amber-700 dark:text-amber-400">Nº de {product.box_unit_label || "caixas"}</label>
                      <Input
                        type="number" min="0" placeholder="0"
                        value={c?.boxes ?? ""}
                        onChange={e => updateCount(product, "boxes", e.target.value)}
                        className="bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div className="flex-1 space-y-1">
                      <label className="text-xs text-amber-700 dark:text-amber-400">Unidades avulsas</label>
                      <Input
                        type="number" min="0" placeholder="0"
                        value={c?.extra_units ?? ""}
                        onChange={e => updateCount(product, "extra_units", e.target.value)}
                        className="bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div className="text-center">
                      <p className="text-xs text-amber-600 dark:text-amber-400">Total</p>
                      <p className="text-xl font-bold text-amber-800 dark:text-amber-200">{c?.quantity ?? "—"}</p>
                      <p className="text-xs text-amber-500">{product.unit || "un"}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <label className="text-sm text-slate-500 dark:text-slate-400 whitespace-nowrap">Quantidade contada:</label>
                  <Input
                    type="number" min="0" placeholder={`Atual: ${product.quantity || 0}`}
                    value={c?.quantity ?? ""}
                    onChange={e => updateCount(product, "quantity", e.target.value)}
                    className="w-40"
                  />
                  <span className="text-sm text-slate-400">{product.unit || ""}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Save bar */}
      {filtered.length > 0 && (
        <div className="sticky bottom-4 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 shadow-lg flex items-center justify-between gap-4">
          <div>
            <p className="font-semibold text-slate-700 dark:text-slate-200">
              {changedProducts.length > 0 ? `${changedProducts.length} produto(s) com alteração` : "Nenhuma alteração ainda"}
            </p>
            {changedProducts.length > 0 && (
              <p className="text-xs text-slate-400 mt-0.5">{changedProducts.map(p => p.name).join(", ")}</p>
            )}
          </div>
          <Button
            onClick={handleSalvar}
            disabled={saving || changedProducts.length === 0}
            className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2 min-w-[140px]"
          >
            <CheckCircle2 className="w-4 h-4" />
            {saving ? "Salvando..." : "Salvar Contagem"}
          </Button>
        </div>
      )}
    </div>
  );
}

// ─── Entrada Tab ──────────────────────────────────────────────────────────────

function EntradaTab({ products, suppliers, sectors, stores, settings }) {
  const queryClient = useQueryClient();
  const { user } = usePermissions();
  const [storeFilter, setStoreFilter] = useState("all");
  const [form, setForm] = useState({
    product_id: "",
    quantity: "",
    boxes: "",
    extra_units: "",
    unit_price: "",
    supplier_name: "",
    destination_sector: "",
    movement_date: format(new Date(), "yyyy-MM-dd"),
    notes: "",
  });
  const [saving, setSaving] = useState(false);

  const activeStores = useMemo(() => stores.filter(s => s.active !== false), [stores]);

  const selectedStore = useMemo(() => {
    if (storeFilter === "all") return null;
    return activeStores.find(s => String(s.id) === String(storeFilter)) || null;
  }, [storeFilter, activeStores]);

  const selectedStoreTypes = useMemo(() => {
    if (!selectedStore) return null;
    if (selectedStore.kitchen_types?.length > 0) return selectedStore.kitchen_types;
    if (selectedStore.kitchen_type) return [selectedStore.kitchen_type];
    return null;
  }, [selectedStore]);

  const allKnownKitchenTypes = useMemo(() => {
    return [...new Set(stores.flatMap(s => s.kitchen_types || []))].map(t => t.toLowerCase());
  }, [stores]);

  const productMatchesStore = (p) => {
    if (!selectedStoreTypes) return true;
    const storeTypesLower = selectedStoreTypes.map(t => t.toLowerCase());
    const productKitchenTypes = p.kitchen_types || [];

    if (productKitchenTypes.length > 0) {
      return productKitchenTypes.some(t => storeTypesLower.includes(t.toLowerCase()));
    }

    const cat = (p.category || "").toLowerCase();
    const matchedKitchen = allKnownKitchenTypes.find(kt => kt.includes(cat) || cat.includes(kt));
    if (matchedKitchen) {
      return storeTypesLower.some(kt => kt.includes(cat) || cat.includes(kt));
    }
    return true;
  };

  const availableProducts = useMemo(() => {
    return products.filter(p => {
      if (p.status !== "ativo") return false;
      return productMatchesStore(p);
    });
  }, [products, selectedStoreTypes, allKnownKitchenTypes]);

  const selectedProduct = products.find(p => p.id === form.product_id);
  const isBoxCounting = selectedProduct?.has_box_counting;

  const updateField = (field, value) => {
    setForm(prev => {
      const updated = { ...prev, [field]: value };

      if (isBoxCounting && (field === "boxes" || field === "extra_units")) {
        const boxes = Number(field === "boxes" ? value : prev.boxes) || 0;
        const extra = Number(field === "extra_units" ? value : prev.extra_units) || 0;
        updated.quantity = boxes * (selectedProduct?.units_per_box || 1) + extra;
      }

      return updated;
    });
  };

  const handleProductChange = (productId) => {
    setForm(prev => ({ ...prev, product_id: productId, boxes: "", extra_units: "", quantity: "" }));
  };

  const handleSalvar = async () => {
    if (!form.product_id || !form.quantity || Number(form.quantity) <= 0) {
      toast.error("Selecione o produto e informe a quantidade.");
      return;
    }

    setSaving(true);
    try {
      const qty = Number(form.quantity);
      const unitPrice = Number(form.unit_price) || 0;
      const product = products.find(p => p.id === form.product_id);

      await db.entities.StockMovement.create({
        product_id: form.product_id,
        product_name: product?.name || "",
        type: "entrada",
        quantity: qty,
        unit_price: unitPrice,
        total_value: qty * unitPrice,
        supplier_name: form.supplier_name || "",
        destination_sector: form.destination_sector || "",
        movement_date: form.movement_date,
        notes: form.notes || "",
      });

      await db.entities.Product.update(form.product_id, {
        quantity: (product?.quantity || 0) + qty,
      });

      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["movements"] });

      openWhatsAppNotification({
        whatsappNumber: settings?.whatsapp_number,
        userName: user?.full_name || user?.email || "Funcionário",
        action: `Entrada de estoque registrada`,
        details: `• Produto: ${product?.name}\n• Quantidade: +${qty} ${product?.unit || ""}\n• Fornecedor: ${form.supplier_name || "—"}\n• Setor: ${form.destination_sector || "—"}${form.notes ? `\n• Obs: ${form.notes}` : ""}`,
      });

      setForm({
        product_id: "",
        quantity: "",
        boxes: "",
        extra_units: "",
        unit_price: "",
        supplier_name: "",
        destination_sector: "",
        movement_date: format(new Date(), "yyyy-MM-dd"),
        notes: "",
      });

      toast.success("Entrada registrada com sucesso!");
    } catch (e) {
      toast.error("Erro ao registrar entrada.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5 max-w-2xl">
      <div className="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-700 rounded-xl p-4">
        <p className="text-sm text-emerald-700 dark:text-emerald-300 font-medium">
          📦 Registre a entrada de produtos recebidos. O estoque será atualizado automaticamente.
        </p>
      </div>

      <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl p-6 space-y-5">
        {/* Store filter */}
        {activeStores.length > 0 && (
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Selecione a loja</label>
            <Select value={storeFilter} onValueChange={v => { setStoreFilter(v); setForm(f => ({ ...f, product_id: "", quantity: "", boxes: "", extra_units: "" })); }}>
              <SelectTrigger>
                <SelectValue placeholder="Todas as lojas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as lojas</SelectItem>
                {activeStores.map(s => (
                  <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Product */}
        <div className="space-y-1.5">
          <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Produto *</label>
          <Select value={form.product_id} onValueChange={handleProductChange}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o produto" />
            </SelectTrigger>
            <SelectContent>
              {availableProducts.map(p => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name} <span className="text-slate-400 text-xs ml-1">(estoque: {p.quantity || 0} {p.unit || ""})</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Quantity */}
        {form.product_id && (
          isBoxCounting ? (
            <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-lg p-4 space-y-3">
              <p className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                1 {selectedProduct.box_unit_label || "caixa"} = {selectedProduct.units_per_box || 1} {selectedProduct.unit || "unidade"}(s)
              </p>
              <div className="flex gap-3 items-end">
                <div className="flex-1 space-y-1">
                  <label className="text-xs text-amber-700 dark:text-amber-400">Nº de {selectedProduct.box_unit_label || "caixas"}</label>
                  <Input type="number" min="0" placeholder="0" value={form.boxes} onChange={e => updateField("boxes", e.target.value)} className="bg-white dark:bg-slate-800" />
                </div>
                <div className="flex-1 space-y-1">
                  <label className="text-xs text-amber-700 dark:text-amber-400">Unidades avulsas</label>
                  <Input type="number" min="0" placeholder="0" value={form.extra_units} onChange={e => updateField("extra_units", e.target.value)} className="bg-white dark:bg-slate-800" />
                </div>
                <div className="text-center pb-1">
                  <p className="text-xs text-amber-600 dark:text-amber-400">Total</p>
                  <p className="text-2xl font-bold text-amber-800 dark:text-amber-200">{form.quantity || "—"}</p>
                  <p className="text-xs text-amber-500">{selectedProduct.unit || "un"}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Quantidade *</label>
              <div className="flex gap-2 items-center">
                <Input type="number" min="1" placeholder="0" value={form.quantity} onChange={e => updateField("quantity", e.target.value)} className="max-w-[160px]" />
                <span className="text-sm text-slate-400">{selectedProduct?.unit || ""}</span>
              </div>
            </div>
          )
        )}

        {/* Date + Unit Price */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Data de entrada *</label>
            <Input type="date" value={form.movement_date} onChange={e => updateField("movement_date", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Valor unitário (R$)</label>
            <Input type="number" min="0" step="0.01" placeholder="0,00" value={form.unit_price} onChange={e => updateField("unit_price", e.target.value)} />
          </div>
        </div>

        {/* Supplier + Sector */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Fornecedor</label>
            <Select value={form.supplier_name} onValueChange={v => updateField("supplier_name", v)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione (opcional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>Nenhum</SelectItem>
                {suppliers.filter(s => s.status === "ativo").map(s => (
                  <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Setor de destino</label>
            <Select value={form.destination_sector} onValueChange={v => updateField("destination_sector", v)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione (opcional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>Nenhum</SelectItem>
                {sectors.filter(s => s.active !== false).map(s => (
                  <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Notes */}
        <div className="space-y-1.5">
          <label className="text-sm font-medium text-slate-700 dark:text-slate-300">Observações</label>
          <Input placeholder="Nota fiscal, lote, etc." value={form.notes} onChange={e => updateField("notes", e.target.value)} />
        </div>

        <Button
          onClick={handleSalvar}
          disabled={saving || !form.product_id || !form.quantity || Number(form.quantity) <= 0}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white gap-2 h-11"
        >
          <PackagePlus className="w-5 h-5" />
          {saving ? "Registrando..." : "Registrar Entrada"}
        </Button>
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function StockCount() {
  const { data: products = [] } = useQuery({
    queryKey: ["products"],
    queryFn: () => db.entities.Product.list("-created_date"),
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers"],
    queryFn: () => db.entities.Supplier.list(),
  });

  const { data: sectors = [] } = useQuery({
    queryKey: ["sectors"],
    queryFn: () => db.entities.Sector.list(),
  });

  const { data: stores = [] } = useQuery({
    queryKey: ["stores"],
    queryFn: () => db.entities.Store.list("name"),
  });

  const { data: settingsList = [] } = useQuery({
    queryKey: ["app_settings"],
    queryFn: () => db.entities.AppSettings.list(),
  });
  const settings = settingsList[0] || null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100">Área do Funcionário</h1>
        <p className="text-slate-500 dark:text-slate-400 mt-1">Contagem de estoque e registro de entradas</p>
      </div>

      <Tabs defaultValue="contagem" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="contagem" className="gap-2">
            <ClipboardList className="w-4 h-4" />
            Contagem de Estoque
          </TabsTrigger>
          <TabsTrigger value="entrada" className="gap-2">
            <PackagePlus className="w-4 h-4" />
            Registrar Entrada
          </TabsTrigger>
        </TabsList>

        <TabsContent value="contagem">
          <ContagemTab products={products} stores={stores} settings={settings} />
        </TabsContent>

        <TabsContent value="entrada">
          <EntradaTab products={products} suppliers={suppliers} sectors={sectors} stores={stores} settings={settings} />
        </TabsContent>
      </Tabs>
    </div>
  );
}