const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Plus, Search, MoreHorizontal, Pencil, Trash2, CheckCircle2,
  ShoppingCart, PackageCheck, ArrowDownLeft, ArrowUpRight,
} from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

import OrderFormDialog from "@/components/orders/OrderFormDialog";
import OrderStatusBadge from "@/components/orders/OrderStatusBadge";
import { usePermissions } from "@/components/auth/usePermissions";

export default function Orders() {
  const { can } = usePermissions();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [formType, setFormType] = useState("compra");
  const [editingOrder, setEditingOrder] = useState(null);
  const [deletingOrder, setDeletingOrder] = useState(null);
  const [completingOrder, setCompletingOrder] = useState(null);

  const queryClient = useQueryClient();

  const { data: orders = [] } = useQuery({
    queryKey: ["orders"],
    queryFn: () => db.entities.Order.list("-order_date", 200),
  });

  const { data: products = [] } = useQuery({
    queryKey: ["products"],
    queryFn: () => db.entities.Product.list("-created_date"),
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers"],
    queryFn: () => db.entities.Supplier.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.Order.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["orders"] }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => db.entities.Order.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["orders"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      queryClient.invalidateQueries({ queryKey: ["movements"] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => db.entities.Order.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["orders"] }),
  });

  const handleSave = async (formData) => {
    if (editingOrder) {
      await updateMutation.mutateAsync({ id: editingOrder.id, data: formData });
    } else {
      await createMutation.mutateAsync(formData);
    }
  };

  const handleComplete = async () => {
    const order = completingOrder;
    const today = format(new Date(), "yyyy-MM-dd");

    // Update each product stock
    for (const item of (order.items || [])) {
      const product = products.find(p => p.id === item.product_id);
      if (!product) continue;

      let newQty = product.quantity || 0;
      if (order.type === "compra") newQty += item.quantity;
      else newQty = Math.max(0, newQty - item.quantity);

      await db.entities.Product.update(product.id, { quantity: newQty });

      await db.entities.StockMovement.create({
        product_id: item.product_id,
        product_name: item.product_name,
        type: order.type === "compra" ? "entrada" : "saida",
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_value: item.total,
        supplier_name: order.supplier_name || "",
        movement_date: today,
        reason: `Pedido ${order.order_number || order.id} - ${order.type === "compra" ? "Compra" : "Venda"}`,
      });
    }

    await updateMutation.mutateAsync({
      id: order.id,
      data: { status: "concluido", stock_updated: true, completed_date: today },
    });

    setCompletingOrder(null);
    toast.success("Pedido concluído e estoque atualizado!");
  };

  const handleDelete = async () => {
    await deleteMutation.mutateAsync(deletingOrder.id);
    setDeletingOrder(null);
  };

  const openNew = (type) => {
    setFormType(type);
    setEditingOrder(null);
    setFormOpen(true);
  };

  const filtered = orders.filter(o => {
    const matchSearch =
      o.order_number?.toLowerCase().includes(search.toLowerCase()) ||
      o.supplier_name?.toLowerCase().includes(search.toLowerCase()) ||
      o.customer_name?.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || o.type === typeFilter;
    const matchStatus = statusFilter === "all" || o.status === statusFilter;
    return matchSearch && matchType && matchStatus;
  });

  const totalCompras = orders.filter(o => o.type === "compra" && o.status === "concluido")
    .reduce((s, o) => s + (o.total_value || 0), 0);
  const totalVendas = orders.filter(o => o.type === "venda" && o.status === "concluido")
    .reduce((s, o) => s + (o.total_value || 0), 0);
  const pendentes = orders.filter(o => ["confirmado", "em_andamento"].includes(o.status)).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800">Pedidos</h1>
          <p className="text-slate-500 mt-1">{orders.length} pedidos registrados</p>
        </div>
        {can("create_orders") && (
          <div className="flex gap-2">
            <Button onClick={() => openNew("compra")} variant="outline" className="border-[#1e3a5f] text-[#1e3a5f] hover:bg-blue-50">
              <ArrowDownLeft className="w-4 h-4 mr-2" /> Pedido de Compra
            </Button>
            <Button onClick={() => openNew("venda")} className="bg-[#1e3a5f] hover:bg-[#2d5a8e]">
              <ArrowUpRight className="w-4 h-4 mr-2" /> Pedido de Venda
            </Button>
          </div>
        )}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-200/60 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center">
              <ArrowDownLeft className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wide">Compras Concluídas</p>
              <p className="text-xl font-bold text-slate-800">
                R$ {totalCompras.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200/60 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
              <ArrowUpRight className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wide">Vendas Concluídas</p>
              <p className="text-xl font-bold text-slate-800">
                R$ {totalVendas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-2xl border border-slate-200/60 p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center">
              <ShoppingCart className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-xs text-slate-400 uppercase tracking-wide">Pedidos Pendentes</p>
              <p className="text-xl font-bold text-slate-800">{pendentes}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Buscar por número, fornecedor ou cliente..." value={search}
            onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full sm:w-44"><SelectValue placeholder="Tipo" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Tipos</SelectItem>
            <SelectItem value="compra">Compra</SelectItem>
            <SelectItem value="venda">Venda</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-44"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="rascunho">Rascunho</SelectItem>
            <SelectItem value="confirmado">Confirmado</SelectItem>
            <SelectItem value="em_andamento">Em Andamento</SelectItem>
            <SelectItem value="concluido">Concluído</SelectItem>
            <SelectItem value="cancelado">Cancelado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200/60 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50/80">
                <TableHead className="font-semibold text-slate-600">Tipo</TableHead>
                <TableHead className="font-semibold text-slate-600">Número</TableHead>
                <TableHead className="font-semibold text-slate-600">Fornecedor/Cliente</TableHead>
                <TableHead className="font-semibold text-slate-600">Data</TableHead>
                <TableHead className="font-semibold text-slate-600">Previsão</TableHead>
                <TableHead className="font-semibold text-slate-600">Itens</TableHead>
                <TableHead className="font-semibold text-slate-600 text-right">Total</TableHead>
                <TableHead className="font-semibold text-slate-600">Status</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12 text-slate-400">
                    Nenhum pedido encontrado
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map(order => (
                  <TableRow key={order.id} className="hover:bg-slate-50/50">
                    <TableCell>
                      <div className={cn(
                        "flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full w-fit",
                        order.type === "compra"
                          ? "bg-emerald-50 text-emerald-700"
                          : "bg-blue-50 text-blue-700"
                      )}>
                        {order.type === "compra"
                          ? <><ArrowDownLeft className="w-3.5 h-3.5" /> Compra</>
                          : <><ArrowUpRight className="w-3.5 h-3.5" /> Venda</>}
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm text-slate-600">
                      {order.order_number || `#${order.id.slice(-6)}`}
                    </TableCell>
                    <TableCell className="font-medium text-slate-800">
                      {order.type === "compra" ? (order.supplier_name || "—") : (order.customer_name || "—")}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">
                      {order.order_date ? format(new Date(order.order_date), "dd/MM/yyyy", { locale: ptBR }) : "—"}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">
                      {order.expected_date ? format(new Date(order.expected_date), "dd/MM/yyyy", { locale: ptBR }) : "—"}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500 text-center">
                      {(order.items || []).length}
                    </TableCell>
                    <TableCell className="text-right font-semibold text-slate-800 text-sm">
                      R$ {(order.total_value || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell><OrderStatusBadge status={order.status} /></TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                         <DropdownMenuItem onClick={() => { setEditingOrder(order); setFormOpen(true); }}>
                           <Pencil className="w-4 h-4 mr-2" /> Editar
                         </DropdownMenuItem>
                         {!order.stock_updated && order.status !== "cancelado" && (order.items || []).length > 0 && (
                           <>
                             <DropdownMenuSeparator />
                             <DropdownMenuItem
                               className="text-emerald-700 font-medium"
                               onClick={() => setCompletingOrder(order)}
                             >
                               <CheckCircle2 className="w-4 h-4 mr-2" />
                               Concluir e Atualizar Estoque
                             </DropdownMenuItem>
                           </>
                         )}
                         {order.stock_updated && (
                           <DropdownMenuItem disabled className="text-slate-400 text-xs">
                             <PackageCheck className="w-4 h-4 mr-2" /> Estoque já atualizado
                           </DropdownMenuItem>
                         )}
                         {can("delete_orders") && (
                           <>
                             <DropdownMenuSeparator />
                             <DropdownMenuItem className="text-red-600" onClick={() => setDeletingOrder(order)}>
                               <Trash2 className="w-4 h-4 mr-2" /> Excluir
                             </DropdownMenuItem>
                           </>
                         )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <OrderFormDialog
        open={formOpen}
        onOpenChange={(v) => { setFormOpen(v); if (!v) setEditingOrder(null); }}
        order={editingOrder}
        products={products}
        suppliers={suppliers}
        onSave={handleSave}
      />

      {/* Confirm Complete */}
      <AlertDialog open={!!completingOrder} onOpenChange={() => setCompletingOrder(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Concluir Pedido</AlertDialogTitle>
            <AlertDialogDescription>
              Isso irá marcar o pedido como <strong>Concluído</strong> e atualizar automaticamente o estoque
              ({completingOrder?.type === "compra" ? "entrada" : "saída"} dos itens). Confirma?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleComplete} className="bg-emerald-600 hover:bg-emerald-700">
              Confirmar e Atualizar Estoque
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Confirm Delete */}
      <AlertDialog open={!!deletingOrder} onOpenChange={() => setDeletingOrder(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Pedido</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir o pedido <strong>{deletingOrder?.order_number || `#${deletingOrder?.id?.slice(-6)}`}</strong>?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}