const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Settings as SettingsIcon, MessageCircle, Save } from "lucide-react";
import PermissionGuard from "@/components/auth/PermissionGuard";
import { toast } from "sonner";

const LOGO_URL = "https://media.db.com/images/public/69ba0915910a22001f6bf92b/3cba5cae7_LOGOMORAISINSTITUICAO.png";

export default function Settings() {
  const [whatsapp, setWhatsapp] = useState("");
  const [saving, setSaving] = useState(false);

  const { data: settingsList = [], refetch } = useQuery({
    queryKey: ["app_settings"],
    queryFn: () => db.entities.AppSettings.list(),
  });
  const settings = settingsList[0] || null;

  useEffect(() => {
    if (settings) setWhatsapp(settings.whatsapp_number || "");
  }, [settings]);

  const handleSave = async () => {
    setSaving(true);
    if (settings) {
      await db.entities.AppSettings.update(settings.id, { whatsapp_number: whatsapp });
    } else {
      await db.entities.AppSettings.create({ whatsapp_number: whatsapp });
    }
    await refetch();
    setSaving(false);
    toast.success("Configurações salvas!");
  };

  return (
    <PermissionGuard requiredRole="admin">
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-foreground">Configurações</h1>
        <p className="text-muted-foreground mt-1">Personalize o sistema</p>
      </div>

      {/* Branding */}
      <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
        <h2 className="font-semibold text-lg flex items-center gap-2"><SettingsIcon className="w-5 h-5" /> Identidade Visual</h2>
        <div className="flex items-center gap-4">
          <img src={LOGO_URL} alt="Logo" className="w-16 h-16 rounded-xl object-cover border border-border" />
          <div>
            <p className="font-bold text-foreground">O MORAIS</p>
            <p className="text-sm text-muted-foreground">Sistema de Gestão de Estoque · Desde 2019</p>
          </div>
        </div>
      </div>

      {/* WhatsApp */}
      <div className="bg-card border border-border rounded-2xl p-6 space-y-4">
        <h2 className="font-semibold text-lg flex items-center gap-2">
          <MessageCircle className="w-5 h-5 text-green-600" /> Notificações WhatsApp
        </h2>
        <p className="text-sm text-muted-foreground">
          Toda vez que um funcionário registrar uma entrada ou contagem, o sistema abrirá o WhatsApp com uma mensagem pronta para enviar ao número abaixo.
        </p>
        <div className="space-y-1.5">
          <Label>Número do WhatsApp (com DDI)</Label>
          <Input
            placeholder="Ex: 5521999999999"
            value={whatsapp}
            onChange={e => setWhatsapp(e.target.value.replace(/\D/g, ""))}
            className="max-w-xs"
          />
          <p className="text-xs text-muted-foreground">Formato: 55 + DDD + número. Ex: 5521998765432</p>
        </div>
        <Button onClick={handleSave} disabled={saving} className="gap-2">
          <Save className="w-4 h-4" />
          {saving ? "Salvando..." : "Salvar Configurações"}
        </Button>
      </div>
    </div>
    </PermissionGuard>
  );
}