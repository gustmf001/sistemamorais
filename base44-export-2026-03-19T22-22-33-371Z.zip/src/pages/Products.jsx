const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Filter, FileDown, FileSpreadsheet, Shield, Tags } from "lucide-react";
import { usePermissions } from "@/components/auth/usePermissions";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

import ProductTable from "@/components/products/ProductTable";
import ProductFormDialog from "@/components/products/ProductFormDialog";
import CategoryManagerDialog from "@/components/products/CategoryManagerDialog";

export default function Products() {
  const [search, setSearch] = useState("");
  const [skuFilter, setSkuFilter] = useState("");
  const [supplierFilter, setSupplierFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [deletingProduct, setDeletingProduct] = useState(null);
  const [categoryDialogOpen, setCategoryDialogOpen] = useState(false);
  const [storeFilter, setStoreFilter] = useState("all");
  const { isAdmin, can } = usePermissions();
  const queryClient = useQueryClient();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: () => db.entities.Product.list("-created_date"),
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers"],
    queryFn: () => db.entities.Supplier.list(),
  });

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => db.entities.Category.list("name"),
  });

  const { data: stores = [] } = useQuery({
    queryKey: ["stores"],
    queryFn: () => db.entities.Store.list("name"),
  });

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.Product.create(data),
    onSuccess: (newProduct) => {
      queryClient.setQueryData(["products"], (old = []) => [newProduct, ...old]);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => db.entities.Product.update(id, data),
    onSuccess: (updated) => {
      queryClient.setQueryData(["products"], (old = []) =>
        old.map(p => p.id === updated.id ? updated : p)
      );
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => db.entities.Product.delete(id),
    onSuccess: (_, id) => {
      queryClient.setQueryData(["products"], (old = []) => old.filter(p => p.id !== id));
    },
  });

  const handleSave = async (formData) => {
    if (!can("edit_products")) { toast.error("Sem permissão para esta ação."); return; }
    if (editingProduct) {
      await updateMutation.mutateAsync({ id: editingProduct.id, data: formData });
    } else {
      await createMutation.mutateAsync(formData);
    }
  };

  const handleEdit = (product) => {
    if (!can("edit_products")) { toast.error("Sem permissão para editar produtos."); return; }
    setEditingProduct(product);
    setFormOpen(true);
  };

  const handleDelete = async () => {
    await deleteMutation.mutateAsync(deletingProduct.id);
    setDeletingProduct(null);
  };

  const handleDeleteRequest = (product) => {
    if (!can("delete_products")) { toast.error("Apenas administradores podem excluir produtos."); return; }
    setDeletingProduct(product);
  };

  const filtered = products.filter((p) => {
    const matchSearch = p.name?.toLowerCase().includes(search.toLowerCase());
    const matchSku = p.sku?.toLowerCase().includes(skuFilter.toLowerCase());
    const matchCategory = categoryFilter === "all" || p.category === categoryFilter;
    const matchSupplier = supplierFilter === "all" || p.supplier_name === supplierFilter;
    const matchStore = storeFilter === "all" || (p.kitchen_types || []).includes(storeFilter);
    return matchSearch && matchSku && matchCategory && matchSupplier && matchStore;
  });

  const exportPDF = async () => {
    const { jsPDF } = await import("jspdf");
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("Relatório de Produtos - EstoqueHub", 14, 20);
    doc.setFontSize(10);
    doc.text(`Gerado em: ${new Date().toLocaleDateString("pt-BR")}`, 14, 28);
    doc.text(`Total: ${filtered.length} produtos`, 14, 34);

    let y = 44;
    doc.setFontSize(9);
    doc.setFont(undefined, "bold");
    doc.text("Nome", 14, y);
    doc.text("SKU", 80, y);
    doc.text("Qtd.", 110, y);
    doc.text("Valor Unit.", 130, y);
    doc.text("Total", 162, y);
    y += 6;
    doc.setFont(undefined, "normal");
    doc.line(14, y - 2, 200, y - 2);

    filtered.forEach(p => {
      if (y > 270) { doc.addPage(); y = 20; }
      const isLow = p.quantity <= p.min_quantity;
      if (isLow) doc.setTextColor(220, 50, 50);
      doc.text((p.name || "").substring(0, 30), 14, y);
      doc.setTextColor(0, 0, 0);
      doc.text(p.sku || "—", 80, y);
      doc.text(String(p.quantity || 0), 110, y);
      doc.text(`R$ ${(p.unit_price || 0).toFixed(2)}`, 130, y);
      doc.text(`R$ ${((p.quantity || 0) * (p.unit_price || 0)).toFixed(2)}`, 162, y);
      y += 7;
    });

    doc.save("produtos-estoquehub.pdf");
    toast.success("PDF exportado!");
  };

  const exportExcel = () => {
    const headers = ["Nome", "SKU", "Categoria", "Quantidade", "Qtd Mínima", "Qtd Ideal", "Valor Unitário", "Valor Total", "Fornecedor", "Localização", "Status"];
    const rows = filtered.map(p => [
      p.name, p.sku || "", p.category || "", p.quantity || 0,
      p.min_quantity || 0, p.ideal_quantity || 0,
      p.unit_price || 0, (p.quantity || 0) * (p.unit_price || 0),
      p.supplier_name || "", p.location || "", p.status || ""
    ]);
    const csv = [headers, ...rows].map(r => r.map(v => `"${v}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "produtos-estoquehub.csv"; a.click();
    URL.revokeObjectURL(url);
    toast.success("Excel exportado!");
  };

  const uniqueSuppliers = [...new Set(products.map(p => p.supplier_name).filter(Boolean))];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100">Produtos</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">{products.length} produtos cadastrados</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={exportExcel} className="gap-1.5">
            <FileSpreadsheet className="w-4 h-4" /> Excel
          </Button>
          <Button variant="outline" size="sm" onClick={exportPDF} className="gap-1.5">
            <FileDown className="w-4 h-4" /> PDF
          </Button>
          {isAdmin && (
            <Button variant="outline" size="sm" onClick={() => setCategoryDialogOpen(true)} className="gap-1.5">
              <Tags className="w-4 h-4" /> Categorias
            </Button>
          )}
          {can("create_products") && (
            <Button onClick={() => { setEditingProduct(null); setFormOpen(true); }} className="bg-[#1e3a5f] hover:bg-[#2d5a8e]">
              <Plus className="w-4 h-4 mr-2" /> Novo Produto
            </Button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Buscar por nome..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Input placeholder="Filtrar por SKU..." value={skuFilter} onChange={e => setSkuFilter(e.target.value)} className="w-full sm:w-36" />
        <Select value={supplierFilter} onValueChange={setSupplierFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="w-4 h-4 mr-2 text-slate-400" />
            <SelectValue placeholder="Fornecedor" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos Fornecedores</SelectItem>
            {uniqueSuppliers.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Categoria" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas as Categorias</SelectItem>
            {categories.map(c => (
              <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {stores.length > 0 && (
          <Select value={storeFilter} onValueChange={setStoreFilter}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Tipo de cozinha" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os tipos</SelectItem>
              {[...new Set(stores.filter(s => s.active !== false).map(s => s.kitchen_type).filter(Boolean))].map(t => (
                <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      <ProductTable products={filtered} onEdit={handleEdit} onDelete={handleDeleteRequest} isAdmin={isAdmin} canEdit={can("edit_products")} canDelete={can("delete_products")} />

      {can("edit_products") && (
        <ProductFormDialog
          open={formOpen}
          onOpenChange={setFormOpen}
          product={editingProduct}
          suppliers={suppliers}
          onSave={handleSave}
        />
      )}

      <CategoryManagerDialog open={categoryDialogOpen} onOpenChange={setCategoryDialogOpen} />

      <AlertDialog open={!!deletingProduct} onOpenChange={() => setDeletingProduct(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir Produto</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir <strong>{deletingProduct?.name}</strong>? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}