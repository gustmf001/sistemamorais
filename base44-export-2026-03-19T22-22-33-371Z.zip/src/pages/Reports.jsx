const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { format, subDays, startOfMonth, endOfMonth, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, CartesianGrid, Legend, PieChart, Pie, Cell,
} from "recharts";
import { TrendingUp, TrendingDown, Package, DollarSign, ArrowDownLeft, ArrowUpRight } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const COLORS = ["#1e3a5f", "#2d5a8e", "#4a90d9", "#7eb8f7", "#b3d4f5", "#d6eafc", "#e8f4ff", "#f0f9ff"];

export default function Reports() {
  const [period, setPeriod] = useState("30");

  const { data: movements = [] } = useQuery({
    queryKey: ["movements"],
    queryFn: () => db.entities.StockMovement.list("-movement_date", 500),
  });

  const { data: products = [] } = useQuery({
    queryKey: ["products"],
    queryFn: () => db.entities.Product.list(),
  });

  const { data: orders = [] } = useQuery({
    queryKey: ["orders"],
    queryFn: () => db.entities.Order.list("-order_date", 500),
  });

  const cutoff = useMemo(() => subDays(new Date(), Number(period)), [period]);

  const filteredMovements = useMemo(() =>
    movements.filter(m => m.movement_date && parseISO(m.movement_date) >= cutoff),
    [movements, cutoff]
  );

  // Daily movement chart
  const dailyData = useMemo(() => {
    const map = {};
    filteredMovements.forEach(m => {
      const d = m.movement_date;
      if (!map[d]) map[d] = { date: d, entradas: 0, saidas: 0 };
      if (m.type === "entrada") map[d].entradas += m.total_value || 0;
      if (m.type === "saida") map[d].saidas += m.total_value || 0;
    });
    return Object.values(map).sort((a, b) => a.date.localeCompare(b.date)).map(d => ({
      ...d,
      date: format(parseISO(d.date), "dd/MM"),
    }));
  }, [filteredMovements]);

  // Top products by exits
  const topProducts = useMemo(() => {
    const map = {};
    filteredMovements.filter(m => m.type === "saida").forEach(m => {
      if (!map[m.product_name]) map[m.product_name] = 0;
      map[m.product_name] += m.quantity || 0;
    });
    return Object.entries(map).map(([name, qty]) => ({ name, qty }))
      .sort((a, b) => b.qty - a.qty).slice(0, 8);
  }, [filteredMovements]);

  // Category distribution
  const categoryData = useMemo(() => {
    const labels = { materia_prima: "Mat. Prima", produto_acabado: "Prod. Acabado", embalagem: "Embalagem", insumo: "Insumo", ferramenta: "Ferramenta", escritorio: "Escritório", limpeza: "Limpeza", outro: "Outro" };
    const map = {};
    products.filter(p => p.status === "ativo").forEach(p => {
      const k = labels[p.category] || p.category;
      if (!map[k]) map[k] = 0;
      map[k]++;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [products]);

  const totalEntradas = filteredMovements.filter(m => m.type === "entrada").reduce((s, m) => s + (m.total_value || 0), 0);
  const totalSaidas = filteredMovements.filter(m => m.type === "saida").reduce((s, m) => s + (m.total_value || 0), 0);
  const totalEstoque = products.filter(p => p.status === "ativo").reduce((s, p) => s + (p.quantity || 0) * (p.unit_price || 0), 0);
  const baixoEstoque = products.filter(p => p.status === "ativo" && p.quantity <= p.min_quantity).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100">Relatórios</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Análise de desempenho do estoque</p>
        </div>
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="w-44">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Últimos 7 dias</SelectItem>
            <SelectItem value="30">Últimos 30 dias</SelectItem>
            <SelectItem value="60">Últimos 60 dias</SelectItem>
            <SelectItem value="90">Últimos 90 dias</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total em Estoque", value: `R$ ${totalEstoque.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, icon: DollarSign, color: "blue", bg: "bg-blue-50 dark:bg-blue-950" },
          { label: "Entradas (período)", value: `R$ ${totalEntradas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, icon: ArrowDownLeft, color: "emerald", bg: "bg-emerald-50 dark:bg-emerald-950" },
          { label: "Saídas (período)", value: `R$ ${totalSaidas.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`, icon: ArrowUpRight, color: "amber", bg: "bg-amber-50 dark:bg-amber-950" },
          { label: "Estoque Baixo", value: `${baixoEstoque} produtos`, icon: Package, color: "red", bg: "bg-red-50 dark:bg-red-950" },
        ].map((kpi, i) => (
          <div key={i} className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 p-5">
            <div className={`w-10 h-10 rounded-xl ${kpi.bg} flex items-center justify-center mb-3`}>
              <kpi.icon className={`w-5 h-5 text-${kpi.color}-600 dark:text-${kpi.color}-400`} />
            </div>
            <p className="text-xs text-slate-400 dark:text-slate-500 uppercase tracking-wide">{kpi.label}</p>
            <p className="text-lg font-bold text-slate-800 dark:text-slate-100 mt-1">{kpi.value}</p>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Line Chart */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 p-6">
          <h3 className="font-semibold text-slate-800 dark:text-slate-100 mb-1">Fluxo de Movimentações</h3>
          <p className="text-xs text-slate-400 dark:text-slate-500 mb-4">Entradas vs Saídas por dia</p>
          {dailyData.length === 0 ? (
            <div className="flex items-center justify-center h-48 text-slate-400 text-sm">Sem dados no período</div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={dailyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={v => `R$ ${v.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`} />
                <Legend />
                <Line type="monotone" dataKey="entradas" stroke="#10b981" strokeWidth={2} dot={false} name="Entradas" />
                <Line type="monotone" dataKey="saidas" stroke="#f59e0b" strokeWidth={2} dot={false} name="Saídas" />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Pie Chart */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 p-6">
          <h3 className="font-semibold text-slate-800 dark:text-slate-100 mb-1">Por Categoria</h3>
          <p className="text-xs text-slate-400 dark:text-slate-500 mb-4">Distribuição dos produtos</p>
          {categoryData.length === 0 ? (
            <div className="flex items-center justify-center h-48 text-slate-400 text-sm">Sem dados</div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={categoryData} dataKey="value" cx="50%" cy="50%" outerRadius={70} innerRadius={35}>
                    {categoryData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1 mt-2">
                {categoryData.slice(0, 5).map((c, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="text-slate-600 dark:text-slate-300 flex-1 truncate">{c.name}</span>
                    <span className="text-slate-400">{c.value}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Top Products Bar */}
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 p-6">
        <h3 className="font-semibold text-slate-800 dark:text-slate-100 mb-1">Produtos Mais Consumidos</h3>
        <p className="text-xs text-slate-400 dark:text-slate-500 mb-4">Quantidade de saídas no período</p>
        {topProducts.length === 0 ? (
          <div className="flex items-center justify-center h-32 text-slate-400 text-sm">Sem saídas no período</div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={topProducts} layout="vertical" margin={{ left: 0, right: 30 }}>
              <XAxis type="number" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis dataKey="name" type="category" width={140} tick={{ fontSize: 11 }}
                tickFormatter={v => v.length > 20 ? v.slice(0, 20) + "…" : v}
                axisLine={false} tickLine={false} />
              <Tooltip formatter={v => [`${v} unid.`, "Saídas"]} />
              <Bar dataKey="qty" fill="#1e3a5f" radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}