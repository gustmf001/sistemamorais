const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Search, ArrowDownLeft, ArrowUpRight, RefreshCw, FileDown, FileSpreadsheet } from "lucide-react";
import { format, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

import MovementFormDialog from "@/components/movements/MovementFormDialog";

const typeConfig = {
  entrada: { icon: ArrowDownLeft, color: "text-emerald-600", bg: "bg-emerald-50 text-emerald-700 border-emerald-200", label: "Entrada" },
  saida: { icon: ArrowUpRight, color: "text-red-500", bg: "bg-red-50 text-red-700 border-red-200", label: "Saída" },
  ajuste: { icon: RefreshCw, color: "text-blue-500", bg: "bg-blue-50 text-blue-700 border-blue-200", label: "Ajuste" },
};

export default function Movements() {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: movements = [] } = useQuery({
    queryKey: ["movements"],
    queryFn: () => db.entities.StockMovement.list("-movement_date", 500),
  });

  const { data: products = [] } = useQuery({
    queryKey: ["products"],
    queryFn: () => db.entities.Product.list("-created_date"),
  });

  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers"],
    queryFn: () => db.entities.Supplier.list(),
  });

  const { data: sectors = [] } = useQuery({
    queryKey: ["sectors"],
    queryFn: () => db.entities.Sector.list("-created_date"),
  });

  const [sectorFilter, setSectorFilter] = useState("all");

  const createMovement = useMutation({
    mutationFn: async (data) => {
      await db.entities.StockMovement.create(data);
      // Refresh products from server to get latest quantity before updating
      const latestProducts = await db.entities.Product.list("-created_date");
      const product = latestProducts.find(p => p.id === data.product_id);
      if (product) {
        let newQuantity = product.quantity || 0;
        if (data.type === "entrada") newQuantity += data.quantity;
        else if (data.type === "saida") newQuantity = Math.max(0, newQuantity - data.quantity);
        else newQuantity = data.quantity;
        await db.entities.Product.update(product.id, { quantity: newQuantity });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["movements"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
    },
  });

  const filtered = movements.filter((m) => {
    const matchSearch = m.product_name?.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || m.type === typeFilter;
    const matchSector = sectorFilter === "all" || m.destination_sector === sectorFilter;
    const matchFrom = !dateFrom || (m.movement_date && m.movement_date >= dateFrom);
    const matchTo = !dateTo || (m.movement_date && m.movement_date <= dateTo);
    return matchSearch && matchType && matchSector && matchFrom && matchTo;
  });

  const exportPDF = async () => {
    const { jsPDF } = await import("jspdf");
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("Histórico de Movimentações - EstoqueHub", 14, 20);
    doc.setFontSize(10);
    doc.text(`Gerado em: ${new Date().toLocaleDateString("pt-BR")}`, 14, 28);

    let y = 40;
    doc.setFontSize(9);
    doc.setFont(undefined, "bold");
    ["Tipo", "Produto", "Data", "Qtd.", "Valor Total", "Motivo"].forEach((h, i) => {
      doc.text(h, [14, 45, 90, 120, 145, 175][i], y);
    });
    y += 6;
    doc.setFont(undefined, "normal");

    filtered.forEach(m => {
      if (y > 270) { doc.addPage(); y = 20; }
      doc.text(m.type || "", 14, y);
      doc.text((m.product_name || "").substring(0, 25), 45, y);
      doc.text(m.movement_date ? format(parseISO(m.movement_date), "dd/MM/yy") : "—", 90, y);
      doc.text(String(m.quantity || 0), 120, y);
      doc.text(`R$ ${(m.total_value || 0).toFixed(2)}`, 145, y);
      doc.text((m.reason || "").substring(0, 20), 175, y);
      y += 7;
    });

    doc.save("movimentacoes-estoquehub.pdf");
    toast.success("PDF exportado!");
  };

  const exportExcel = () => {
    const headers = ["Tipo", "Produto", "Data", "Quantidade", "Valor Unitário", "Valor Total", "Setor", "Fornecedor", "Motivo"];
    const rows = filtered.map(m => [
      m.type, m.product_name, m.movement_date || "",
      m.quantity || 0, m.unit_price || 0, m.total_value || 0,
      m.destination_sector || "", m.supplier_name || "", m.reason || ""
    ]);
    const csv = [headers, ...rows].map(r => r.map(v => `"${v}"`).join(",")).join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "movimentacoes-estoquehub.csv"; a.click();
    URL.revokeObjectURL(url);
    toast.success("Excel exportado!");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100">Movimentações</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">{filtered.length} registros encontrados</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={exportExcel} className="gap-1.5">
            <FileSpreadsheet className="w-4 h-4" /> Excel
          </Button>
          <Button variant="outline" size="sm" onClick={exportPDF} className="gap-1.5">
            <FileDown className="w-4 h-4" /> PDF
          </Button>
          <Button onClick={() => setFormOpen(true)} className="bg-[#1e3a5f] hover:bg-[#2d5a8e]">
            <Plus className="w-4 h-4 mr-2" /> Nova Movimentação
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input placeholder="Buscar por produto..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-full sm:w-40">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Tipos</SelectItem>
            <SelectItem value="entrada">Entrada</SelectItem>
            <SelectItem value="saida">Saída</SelectItem>
            <SelectItem value="ajuste">Ajuste</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sectorFilter} onValueChange={setSectorFilter}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue placeholder="Setor" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Setores</SelectItem>
            {sectors.map(s => (
              <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2">
          <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="w-36" title="De" />
          <span className="text-slate-400 text-sm">até</span>
          <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="w-36" title="Até" />
          {(dateFrom || dateTo) && (
            <Button variant="ghost" size="sm" onClick={() => { setDateFrom(""); setDateTo(""); }}>
              Limpar
            </Button>
          )}
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50/80 dark:bg-slate-700/50">
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Tipo</TableHead>
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Produto</TableHead>
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Data</TableHead>
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300 text-center">Qtd.</TableHead>
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300 text-right">Valor Unit.</TableHead>
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300 text-right">Total</TableHead>
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Setor</TableHead>
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Fornecedor</TableHead>
                <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Motivo</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-12 text-slate-400">
                    Nenhuma movimentação encontrada
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((mov) => {
                  const config = typeConfig[mov.type] || typeConfig.ajuste;
                  const Icon = config.icon;
                  return (
                    <TableRow key={mov.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                      <TableCell>
                        <Badge variant="outline" className={cn("gap-1 font-medium", config.bg)}>
                          <Icon className="w-3 h-3" /> {config.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium text-slate-800 dark:text-slate-100">{mov.product_name}</TableCell>
                      <TableCell className="text-sm text-slate-500 dark:text-slate-400">
                        {mov.movement_date ? format(parseISO(mov.movement_date), "dd/MM/yyyy", { locale: ptBR }) : "—"}
                      </TableCell>
                      <TableCell className={cn("text-center font-semibold", config.color)}>
                        {mov.type === "entrada" ? "+" : mov.type === "saida" ? "-" : "±"}{mov.quantity}
                      </TableCell>
                      <TableCell className="text-right text-sm text-slate-500 dark:text-slate-400">
                        R$ {(mov.unit_price || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-right text-sm font-medium text-slate-800 dark:text-slate-100">
                        R$ {(mov.total_value || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-sm text-slate-500 dark:text-slate-400">{mov.destination_sector || "—"}</TableCell>
                      <TableCell className="text-sm text-slate-500 dark:text-slate-400">{mov.supplier_name || "—"}</TableCell>
                      <TableCell className="text-sm text-slate-500 dark:text-slate-400 max-w-[200px] truncate">{mov.reason || "—"}</TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <MovementFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        products={products}
        suppliers={suppliers}
        sectors={sectors}
        onSave={(data) => createMovement.mutateAsync(data)}
      />
    </div>
  );
}