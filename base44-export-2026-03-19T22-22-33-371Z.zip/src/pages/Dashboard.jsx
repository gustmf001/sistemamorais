const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";
import { useQuery } from "@tanstack/react-query";

import { Package, Truck, ArrowLeftRight, DollarSign, AlertTriangle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

import StatCard from "@/components/dashboard/StatCard";
import DailyPhrase from "@/components/dashboard/DailyPhrase";
import LowStockAlert from "@/components/dashboard/LowStockAlert";
import RecentMovements from "@/components/dashboard/RecentMovements";
import CategoryChart from "@/components/dashboard/CategoryChart";
import ProductUsageChart from "@/components/dashboard/ProductUsageChart";

export default function Dashboard() {
  const { data: products = [], isLoading: loadingProducts } = useQuery({
    queryKey: ["products"],
    queryFn: () => db.entities.Product.list("-created_date"),
  });

  const { data: suppliers = [], isLoading: loadingSuppliers } = useQuery({
    queryKey: ["suppliers"],
    queryFn: () => db.entities.Supplier.list(),
  });

  const { data: movements = [], isLoading: loadingMovements } = useQuery({
    queryKey: ["movements"],
    queryFn: () => db.entities.StockMovement.list("-movement_date", 50),
  });

  const isLoading = loadingProducts || loadingSuppliers || loadingMovements;

  const activeProducts = products.filter(p => p.status === "ativo");
  const totalValue = activeProducts.reduce((sum, p) => sum + (p.quantity || 0) * (p.unit_price || 0), 0);
  const lowStockCount = activeProducts.filter(p => p.quantity <= p.min_quantity).length;
  const activeSuppliers = suppliers.filter(s => s.status === "ativo");

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100">Painel de Controle</h1>
        <p className="text-slate-500 dark:text-slate-400 mt-1">Visão geral do seu estoque</p>
      </div>

      <DailyPhrase />

      {/* Stats */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Array(4).fill(0).map((_, i) => (
            <div key={i} className="bg-white rounded-2xl border border-slate-200/60 p-6">
              <Skeleton className="h-4 w-24 mb-3" />
              <Skeleton className="h-8 w-20 mb-2" />
              <Skeleton className="h-3 w-32" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total de Produtos"
            value={activeProducts.length}
            subtitle={`${products.length} cadastrados`}
            icon={Package}
            color="blue"
          />
          <StatCard
            title="Valor em Estoque"
            value={`R$ ${totalValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
            subtitle="Valor total estimado"
            icon={DollarSign}
            color="green"
          />
          <StatCard
            title="Estoque Baixo"
            value={lowStockCount}
            subtitle="Produtos abaixo do mínimo"
            icon={AlertTriangle}
            color={lowStockCount > 0 ? "red" : "amber"}
          />
          <StatCard
            title="Fornecedores"
            value={activeSuppliers.length}
            subtitle="Fornecedores ativos"
            icon={Truck}
            color="purple"
          />
        </div>
      )}

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <RecentMovements movements={movements} />
          <CategoryChart products={activeProducts} />
          <ProductUsageChart movements={movements} />
        </div>
        <div>
          <LowStockAlert products={products} />
        </div>
      </div>
    </div>
  );
}