const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Store, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import StoreFormDialog from "@/components/stores/StoreFormDialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const kitchenLabels = {
  pizzaria: "🍕 Pizzaria",
  hamburgueria: "🍔 Hamburgueria",
  açaiteria: "🍇 Açaiteria",
  browneria: "🍫 Browneria",
};

const getKitchenLabel = (type) => kitchenLabels[type] || `✏️ ${type}`;

export default function Stores() {
  const [search, setSearch] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const queryClient = useQueryClient();

  const { data: stores = [], isLoading } = useQuery({
    queryKey: ["stores"],
    queryFn: () => db.entities.Store.list("-created_date"),
  });

  const create = useMutation({
    mutationFn: (data) => db.entities.Store.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["stores"] }); toast.success("Loja cadastrada!"); },
  });

  const update = useMutation({
    mutationFn: ({ id, data }) => db.entities.Store.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["stores"] }); toast.success("Loja atualizada!"); },
  });

  const remove = useMutation({
    mutationFn: (id) => db.entities.Store.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["stores"] }); toast.success("Loja excluída!"); setDeleteTarget(null); },
  });

  const handleSave = async (data) => {
    if (editing) {
      await update.mutateAsync({ id: editing.id, data });
    } else {
      await create.mutateAsync(data);
    }
    setEditing(null);
    setFormOpen(false);
  };

  const filtered = stores.filter(s => {
    const q = search.toLowerCase();
    const types = s.kitchen_types?.length ? s.kitchen_types : s.kitchen_type ? [s.kitchen_type] : [];
    return s.name?.toLowerCase().includes(q) || types.some(t => t.toLowerCase().includes(q));
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-slate-100">Lojas</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">{stores.length} loja{stores.length !== 1 ? "s" : ""} cadastrada{stores.length !== 1 ? "s" : ""}</p>
        </div>
        <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="bg-primary hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" /> Nova Loja
        </Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input placeholder="Buscar loja..." value={search} onChange={e => setSearch(e.target.value)} className="pl-10" />
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {isLoading ? (
          <div className="col-span-full flex items-center justify-center py-20 text-slate-400">Carregando...</div>
        ) : filtered.length === 0 ? (
          <div className="col-span-full flex flex-col items-center justify-center py-20 gap-3 text-slate-400">
            <Store className="w-12 h-12 opacity-30" />
            <p className="text-sm">Nenhuma loja cadastrada</p>
            <Button variant="outline" size="sm" onClick={() => setFormOpen(true)}>Cadastrar primeira loja</Button>
          </div>
        ) : filtered.map(store => (
          <div key={store.id} className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 p-5 flex flex-col gap-3">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-lg">{store.name}</h3>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {(store.kitchen_types?.length ? store.kitchen_types : store.kitchen_type ? [store.kitchen_type] : []).map(t => (
                    <Badge key={t} variant="secondary" className="text-xs">{getKitchenLabel(t)}</Badge>
                  ))}
                </div>
              </div>
              <Badge variant="outline" className={store.active !== false ? "bg-emerald-50 text-emerald-700 border-emerald-200" : "bg-slate-100 text-slate-500"}>
                {store.active !== false ? "Ativa" : "Inativa"}
              </Badge>
            </div>
            {store.notes && <p className="text-xs text-slate-400 dark:text-slate-500">{store.notes}</p>}
            <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-100 dark:border-slate-700">
              <Button variant="ghost" size="icon" onClick={() => { setEditing(store); setFormOpen(true); }}>
                <Pencil className="w-4 h-4 text-slate-500" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setDeleteTarget(store)}>
                <Trash2 className="w-4 h-4 text-red-400" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      <StoreFormDialog open={formOpen} onOpenChange={(v) => { setFormOpen(v); if (!v) setEditing(null); }} store={editing} onSave={handleSave} />

      <AlertDialog open={!!deleteTarget} onOpenChange={v => !v && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir loja?</AlertDialogTitle>
            <AlertDialogDescription>A loja <strong>{deleteTarget?.name}</strong> será removida permanentemente.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => remove.mutate(deleteTarget?.id)}>Excluir</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}