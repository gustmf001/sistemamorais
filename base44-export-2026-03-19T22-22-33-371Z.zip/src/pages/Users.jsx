const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

import { Shield, Users as UsersIcon, ShieldCheck, Plus, Pencil, Trash2, UserCheck } from "lucide-react";
import PermissionGuard from "@/components/auth/PermissionGuard";
import { usePermissions } from "@/components/auth/usePermissions";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { toast } from "sonner";
import RoleFormDialog from "@/components/users/RoleFormDialog";
import { clearPermissionsCache } from "@/components/auth/usePermissions";

export default function Users() {
  const { user: currentUser, isAdmin } = usePermissions();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [roleDialog, setRoleDialog] = useState({ open: false, role: null });
  const [deleteRoleTarget, setDeleteRoleTarget] = useState(null);

  const { data: users = [], isLoading, refetch: refetchUsers } = useQuery({
    queryKey: ["users"],
    queryFn: () => db.entities.User.list(),
  });

  const { data: roles = [], refetch: refetchRoles } = useQuery({
    queryKey: ["roles"],
    queryFn: () => db.entities.Role.list(),
  });

  const handleChangeRole = async (user, newRole) => {
    await db.entities.User.update(user.id, { role: newRole });
    toast.success(`Perfil de ${user.full_name || user.email} alterado para ${newRole}`);
    refetchUsers();
  };

  const handleDeleteRole = async () => {
    await db.entities.Role.delete(deleteRoleTarget.id);
    toast.success("Perfil removido");
    setDeleteRoleTarget(null);
    clearPermissionsCache();
    refetchRoles();
  };

  const filtered = users.filter(u =>
    u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  const getRoleLabel = (role) => {
    if (role === "admin") return <Badge className="bg-blue-100 text-blue-700 border-blue-200"><ShieldCheck className="w-3 h-3 mr-1" />Admin</Badge>;
    if (role === "pending") return <Badge className="bg-amber-100 text-amber-700 border-amber-200">⏳ Pendente</Badge>;
    if (!role || role === "user") return <Badge variant="outline">Usuário</Badge>;
    return <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200">{role}</Badge>;
  };

  return (
    <PermissionGuard requiredRole="admin">
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">Usuários & Perfis</h1>
          <p className="text-muted-foreground mt-1">Gerencie usuários e defina perfis de acesso</p>
        </div>
        <Button
          onClick={() => {
            const email = window.prompt("Email do novo usuário:");
            if (email) {
              db.users.inviteUser(email, "user")
                .then(() => { toast.success("Convite enviado para " + email); refetchUsers(); })
                .catch(() => toast.error("Erro ao enviar convite"));
            }
          }}
        >
          <UsersIcon className="w-4 h-4 mr-2" /> Convidar Usuário
        </Button>
      </div>

      <Tabs defaultValue="usuarios">
        <TabsList>
          <TabsTrigger value="usuarios">👥 Usuários</TabsTrigger>
          <TabsTrigger value="perfis">🔐 Perfis de Acesso</TabsTrigger>
        </TabsList>

        {/* USERS TAB */}
        <TabsContent value="usuarios" className="mt-4 space-y-4">
          <div className="relative max-w-sm">
            <Input
              placeholder="Buscar por nome ou email..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          <div className="bg-card rounded-2xl border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead>Usuário</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Perfil</TableHead>
                  <TableHead>Desde</TableHead>
                  <TableHead className="w-48">Alterar Perfil</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow><TableCell colSpan={5} className="text-center py-12 text-muted-foreground">Carregando...</TableCell></TableRow>
                ) : filtered.map(user => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-sm font-semibold">
                          {(user.full_name || user.email || "?")[0].toUpperCase()}
                        </div>
                        <span className="font-medium">{user.full_name || "—"}</span>
                        {user.id === currentUser?.id && <Badge variant="outline" className="text-xs">Você</Badge>}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground text-sm">{user.email}</TableCell>
                    <TableCell>{getRoleLabel(user.role)}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {user.created_date ? format(new Date(user.created_date), "dd/MM/yyyy", { locale: ptBR }) : "—"}
                    </TableCell>
                    <TableCell>
                      {user.id !== currentUser?.id && (
                        <Select value={user.role || "user"} onValueChange={(v) => handleChangeRole(user, v)}>
                          <SelectTrigger className="h-8 text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="admin">Admin (dono)</SelectItem>
                            <SelectItem value="pending">Pendente (sem acesso)</SelectItem>
                            {roles.map(r => (
                              <SelectItem key={r.id} value={r.name}>{r.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>

        {/* ROLES TAB */}
        <TabsContent value="perfis" className="mt-4 space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">Crie perfis personalizados e defina quais páginas cada perfil pode acessar.</p>
            <Button onClick={() => setRoleDialog({ open: true, role: null })} size="sm">
              <Plus className="w-4 h-4 mr-2" /> Novo Perfil
            </Button>
          </div>

          <div className="grid gap-3">
            {/* Built-in roles */}
            <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-500" />
                  <span className="font-semibold">Admin</span>
                  <Badge className="bg-blue-100 text-blue-700 text-xs">Padrão</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Acesso total ao sistema. Não pode ser removido.</p>
              </div>
            </div>
            <div className="bg-card border border-border rounded-xl p-4 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-amber-500" />
                  <span className="font-semibold">Pendente</span>
                  <Badge className="bg-amber-100 text-amber-700 text-xs">Padrão</Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Aguardando autorização. Sem acesso a nenhuma página.</p>
              </div>
            </div>

            {/* Custom roles */}
            {roles.map(role => (
              <div key={role.id} className="bg-card border border-border rounded-xl p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <UserCheck className="w-4 h-4 text-emerald-500" />
                      <span className="font-semibold">{role.name}</span>
                      <Badge className="bg-emerald-100 text-emerald-700 text-xs">Personalizado</Badge>
                    </div>
                    {role.description && <p className="text-xs text-muted-foreground mt-1">{role.description}</p>}
                    <div className="flex flex-wrap gap-1 mt-2">
                      {(role.pages || []).map(p => (
                        <span key={p} className="text-xs bg-muted px-2 py-0.5 rounded">{p}</span>
                      ))}
                      {(!role.pages || role.pages.length === 0) && (
                        <span className="text-xs text-red-500">Nenhuma página liberada</span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2 ml-4">
                    <Button size="sm" variant="outline" onClick={() => setRoleDialog({ open: true, role })}>
                      <Pencil className="w-3 h-3" />
                    </Button>
                    <Button size="sm" variant="outline" className="text-destructive hover:text-destructive" onClick={() => setDeleteRoleTarget(role)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}

            {roles.length === 0 && (
              <div className="text-center py-10 text-muted-foreground text-sm">
                Nenhum perfil personalizado criado ainda. Clique em "Novo Perfil" para começar.
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>

    <RoleFormDialog
      open={roleDialog.open}
      role={roleDialog.role}
      onClose={() => setRoleDialog({ open: false, role: null })}
      onSaved={() => { clearPermissionsCache(); refetchRoles(); queryClient.invalidateQueries(["roles"]); }}
    />

    <AlertDialog open={!!deleteRoleTarget} onOpenChange={() => setDeleteRoleTarget(null)}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Remover perfil "{deleteRoleTarget?.name}"?</AlertDialogTitle>
          <AlertDialogDescription>Usuários com este perfil perderão o acesso. Esta ação não pode ser desfeita.</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancelar</AlertDialogCancel>
          <AlertDialogAction onClick={handleDeleteRole} className="bg-destructive text-destructive-foreground">Remover</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </PermissionGuard>
  );
}