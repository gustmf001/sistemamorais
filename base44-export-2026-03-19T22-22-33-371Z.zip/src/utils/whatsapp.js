export function openWhatsAppNotification({ whatsappNumber, userName, action, details }) {
  const phone = (whatsappNumber || "").replace(/\D/g, "");
  if (!phone) return;

  const now = new Date();
  const date = now.toLocaleDateString("pt-BR");
  const time = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  const lines = [
    "🏪 *O MORAIS - Notificação de Estoque*",
    "",
    `👤 *Usuário:* ${userName}`,
    `📅 *Data/Hora:* ${date} às ${time}`,
    `📋 *Ação:* ${action}`,
  ];
  if (details) {
    lines.push("", "📦 *Detalhes:*", details);
  }

  const message = encodeURIComponent(lines.join("\n"));
  window.open(`https://wa.me/${phone}?text=${message}`, "_blank");
}