const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

import { toast } from "sonner";
import { clearPermissionsCache } from "@/components/auth/usePermissions";

const ALL_PAGES = [
  { key: "Dashboard", label: "📊 Dashboard" },
  { key: "Products", label: "📦 Produtos" },
  { key: "Movements", label: "↔️ Movimentações" },
  { key: "Orders", label: "🛒 Pedidos" },
  { key: "Suppliers", label: "🚚 Fornecedores" },
  { key: "Reports", label: "📈 Relatórios" },
  { key: "Sectors", label: "🏢 Setores" },
  { key: "Stores", label: "🏪 Lojas" },
  { key: "StockCount", label: "📋 Área do Funcionário" },
];

export default function RoleFormDialog({ open, onClose, role, onSaved }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [pages, setPages] = useState([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setName(role?.name || "");
      setDescription(role?.description || "");
      setPages(role?.pages || []);
    }
  }, [role, open]);

  const togglePage = (key) => {
    setPages(prev => prev.includes(key) ? prev.filter(p => p !== key) : [...prev, key]);
  };

  const selectAll = () => setPages(ALL_PAGES.map(p => p.key));
  const clearAll = () => setPages([]);

  const handleSave = async () => {
    if (!name.trim()) return toast.error("Nome é obrigatório");
    setSaving(true);
    try {
      if (role) {
        await db.entities.Role.update(role.id, { name, description, pages });
      } else {
        await db.entities.Role.create({ name, description, pages });
      }
      clearPermissionsCache();
      toast.success(role ? "Perfil atualizado!" : "Perfil criado!");
      onSaved();
      onClose();
    } catch (err) {
      toast.error("Erro ao salvar perfil: " + (err?.message || "tente novamente"));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{role ? "Editar Perfil" : "Novo Perfil de Acesso"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Nome do Perfil *</Label>
            <Input value={name} onChange={e => setName(e.target.value)} placeholder="Ex: Gerente, Funcionário..." className="mt-1" />
          </div>
          <div>
            <Label>Descrição (opcional)</Label>
            <Input value={description} onChange={e => setDescription(e.target.value)} placeholder="Descrição do perfil" className="mt-1" />
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label>Páginas permitidas</Label>
              <div className="flex gap-2">
                <button onClick={selectAll} className="text-xs text-primary underline">Todas</button>
                <button onClick={clearAll} className="text-xs text-muted-foreground underline">Nenhuma</button>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-2 bg-muted/30 rounded-lg p-3">
              {ALL_PAGES.map(p => (
                <div key={p.key} className="flex items-center gap-2">
                  <Checkbox
                    id={`page-${p.key}`}
                    checked={pages.includes(p.key)}
                    onCheckedChange={() => togglePage(p.key)}
                  />
                  <label htmlFor={`page-${p.key}`} className="text-sm cursor-pointer select-none">{p.label}</label>
                </div>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave} disabled={saving}>
            {saving ? "Salvando..." : "Salvar Perfil"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}