import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, Pencil, Trash2, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

const categoryLabels = {
  materia_prima: "Matéria Prima",
  produto_acabado: "Produto Acabado",
  embalagem: "Embalagem",
  insumo: "Insumo",
  ferramenta: "Ferramenta",
  escritorio: "Escritório",
  limpeza: "Limpeza",
  outro: "Outro",
};

export default function ProductTable({ products, onEdit, onDelete, isAdmin = false, canEdit = false, canDelete = false }) {
  const showActions = canEdit || canDelete;
  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50/80 dark:bg-slate-700/50">
              <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Produto</TableHead>
              <TableHead className="font-semibold text-slate-600 dark:text-slate-300">SKU</TableHead>
              <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Categoria</TableHead>
              <TableHead className="font-semibold text-slate-600 dark:text-slate-300 text-center">Qtd.</TableHead>
              <TableHead className="font-semibold text-slate-600 dark:text-slate-300 text-right">Valor Unit.</TableHead>
              <TableHead className="font-semibold text-slate-600 dark:text-slate-300 text-right">Valor Total</TableHead>
              <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Fornecedor</TableHead>
              <TableHead className="font-semibold text-slate-600 dark:text-slate-300">Dimensões (C×L×A)</TableHead>
              {showActions && <TableHead className="w-12"></TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.length === 0 ? (
              <TableRow>
                <TableCell colSpan={showActions ? 9 : 8} className="text-center py-12 text-slate-400">
                  Nenhum produto encontrado
                </TableCell>
              </TableRow>
            ) : (
              products.map((product) => {
                const isLow = product.quantity <= product.min_quantity;
                const totalValue = (product.quantity || 0) * (product.unit_price || 0);
                return (
                  <TableRow key={product.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30 transition-colors">
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-slate-800 dark:text-slate-100">{product.name}</span>
                        {isLow && (
                          <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                        )}
                      </div>
                      {product.location && (
                        <p className="text-xs text-slate-400 mt-0.5">{product.location}</p>
                      )}
                    </TableCell>
                    <TableCell className="text-slate-500 text-sm">{product.sku || "—"}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="bg-slate-100 text-slate-600 font-normal">
                        {categoryLabels[product.category] || product.category}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      <span className={cn(
                        "font-semibold text-sm",
                        isLow ? "text-red-600" : "text-slate-800"
                      )}>
                        {product.quantity}
                      </span>
                      <span className="text-xs text-slate-400 ml-1">/ {product.min_quantity}</span>
                      {product.ideal_quantity > 0 && (
                        <span className="text-xs text-blue-400 ml-1" title="Qtd. Ideal">
                          (ideal: {product.ideal_quantity})
                        </span>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-sm text-slate-600">
                      R$ {(product.unit_price || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell className="text-right text-sm font-medium text-slate-800">
                      R$ {totalValue.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell className="text-sm text-slate-500">{product.supplier_name || "—"}</TableCell>
                    <TableCell className="text-sm text-slate-400">
                      {(product.length || product.width || product.height)
                        ? `${product.length || "—"} × ${product.width || "—"} × ${product.height || "—"} ${product.dimension_unit || "cm"}`
                        : "—"}
                      {product.weight ? <span className="block text-xs">{product.weight} kg</span> : null}
                    </TableCell>
                    {showActions && (
                     <TableCell>
                       <DropdownMenu>
                         <DropdownMenuTrigger asChild>
                           <Button variant="ghost" size="icon" className="h-8 w-8">
                             <MoreHorizontal className="w-4 h-4" />
                           </Button>
                         </DropdownMenuTrigger>
                         <DropdownMenuContent align="end">
                           {canEdit && (
                             <DropdownMenuItem onClick={() => onEdit(product)}>
                               <Pencil className="w-4 h-4 mr-2" /> Editar
                             </DropdownMenuItem>
                           )}
                           {canDelete && (
                             <DropdownMenuItem className="text-red-600" onClick={() => onDelete(product)}>
                               <Trash2 className="w-4 h-4 mr-2" /> Excluir
                             </DropdownMenuItem>
                           )}
                         </DropdownMenuContent>
                       </DropdownMenu>
                     </TableCell>
                    )}
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}