const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Pencil, Trash2, Plus, Loader2, Check, X } from "lucide-react";
import { toast } from "sonner";

const COLORS = [
  "#1e3a5f", "#2d5a8e", "#4a90d9", "#22c55e", "#f59e0b",
  "#ef4444", "#8b5cf6", "#ec4899", "#06b6d4", "#84cc16",
];

function ColorPicker({ value, onChange }) {
  return (
    <div className="flex gap-2 flex-wrap">
      {COLORS.map(c => (
        <button
          key={c}
          type="button"
          onClick={() => onChange(c)}
          className="w-7 h-7 rounded-full border-2 transition-all"
          style={{
            backgroundColor: c,
            borderColor: value === c ? "#1e293b" : "transparent",
            transform: value === c ? "scale(1.2)" : "scale(1)",
          }}
        />
      ))}
    </div>
  );
}

function CategoryRow({ category, onEdit, onDelete }) {
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800 group">
      <div className="flex items-center gap-3">
        <span
          className="w-4 h-4 rounded-full flex-shrink-0"
          style={{ backgroundColor: category.color || "#94a3b8" }}
        />
        <div>
          <p className="text-sm font-medium text-slate-800 dark:text-slate-100">{category.name}</p>
          {category.description && (
            <p className="text-xs text-slate-400">{category.description}</p>
          )}
        </div>
      </div>
      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button size="icon" variant="ghost" className="w-7 h-7" onClick={() => onEdit(category)}>
          <Pencil className="w-3.5 h-3.5" />
        </Button>
        <Button size="icon" variant="ghost" className="w-7 h-7 text-red-500 hover:text-red-600" onClick={() => onDelete(category)}>
          <Trash2 className="w-3.5 h-3.5" />
        </Button>
      </div>
    </div>
  );
}

const emptyForm = { name: "", color: COLORS[0], description: "" };

export default function CategoryManagerDialog({ open, onOpenChange }) {
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  const { data: categories = [], isLoading } = useQuery({
    queryKey: ["categories"],
    queryFn: () => db.entities.Category.list("name"),
  });

  const createMutation = useMutation({
    mutationFn: (data) => db.entities.Category.create(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["categories"] }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => db.entities.Category.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["categories"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => db.entities.Category.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["categories"] }),
  });

  const handleEdit = (cat) => {
    setEditingId(cat.id);
    setForm({ name: cat.name, color: cat.color || COLORS[0], description: cat.description || "" });
  };

  const handleCancel = () => {
    setEditingId(null);
    setForm(emptyForm);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    setSaving(true);
    if (editingId) {
      await updateMutation.mutateAsync({ id: editingId, data: form });
      toast.success("Categoria atualizada!");
    } else {
      await createMutation.mutateAsync(form);
      toast.success("Categoria criada!");
    }
    setSaving(false);
    handleCancel();
  };

  const handleDelete = async (cat) => {
    await deleteMutation.mutateAsync(cat.id);
    toast.success("Categoria excluída!");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Gerenciar Categorias</DialogTitle>
        </DialogHeader>

        {/* Form */}
        <form onSubmit={handleSave} className="space-y-3 border border-slate-200 dark:border-slate-700 rounded-xl p-4 bg-slate-50 dark:bg-slate-800/50">
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            {editingId ? "Editar Categoria" : "Nova Categoria"}
          </p>
          <div className="space-y-1.5">
            <Label>Nome *</Label>
            <Input
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder="Ex: Eletrônicos"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label>Descrição</Label>
            <Input
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder="Opcional"
            />
          </div>
          <div className="space-y-1.5">
            <Label>Cor</Label>
            <ColorPicker value={form.color} onChange={c => setForm(f => ({ ...f, color: c }))} />
          </div>
          <div className="flex gap-2 pt-1">
            <Button type="submit" size="sm" disabled={saving} className="bg-[#1e3a5f] hover:bg-[#2d5a8e]">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4 mr-1" />}
              {editingId ? "Salvar" : "Adicionar"}
            </Button>
            {editingId && (
              <Button type="button" size="sm" variant="outline" onClick={handleCancel}>
                <X className="w-4 h-4 mr-1" /> Cancelar
              </Button>
            )}
          </div>
        </form>

        {/* List */}
        <div className="space-y-1 mt-2">
          {isLoading ? (
            <div className="flex justify-center py-6">
              <Loader2 className="w-5 h-5 animate-spin text-slate-400" />
            </div>
          ) : categories.length === 0 ? (
            <p className="text-center text-slate-400 text-sm py-6">Nenhuma categoria cadastrada.</p>
          ) : (
            categories.map(cat => (
              <CategoryRow key={cat.id} category={cat} onEdit={handleEdit} onDelete={handleDelete} />
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}