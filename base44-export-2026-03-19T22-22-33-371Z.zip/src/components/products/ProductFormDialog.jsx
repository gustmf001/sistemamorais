const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const units = [
  { value: "unidade", label: "Unidade" },
  { value: "kg", label: "Kg" },
  { value: "litro", label: "Litro" },
  { value: "metro", label: "Metro" },
  { value: "caixa", label: "Caixa" },
  { value: "pacote", label: "Pacote" },
  { value: "rolo", label: "Rolo" },
];

const emptyForm = {
  name: "", sku: "", category: "", kitchen_types: [], quantity: 0,
  min_quantity: 5, ideal_quantity: 0, unit_price: 0, unit: "unidade",
  supplier_name: "", location: "", status: "ativo", notes: "",
  has_box_counting: false, box_unit_label: "caixa", units_per_box: 1,
};

export default function ProductFormDialog({ open, onOpenChange, product, suppliers, onSave }) {
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: () => db.entities.Category.list("name"),
  });

  const { data: stores = [] } = useQuery({
    queryKey: ["stores"],
    queryFn: () => db.entities.Store.list("name"),
  });

  // Build unique kitchen types from active stores
  const allKitchenTypes = [...new Set(stores.filter(s => s.active !== false).map(s => s.kitchen_type).filter(Boolean))];

  useEffect(() => {
    if (product) {
      setForm({ ...emptyForm, ...product, kitchen_types: product.kitchen_types || [] });
    } else {
      setForm(emptyForm);
    }
  }, [product, open]);

  const update = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const toggleKitchenType = (type) => {
    setForm(prev => {
      const current = prev.kitchen_types || [];
      return {
        ...prev,
        kitchen_types: current.includes(type)
          ? current.filter(t => t !== type)
          : [...current, type],
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSave(form);
    setSaving(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{product ? "Editar Produto" : "Novo Produto"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Nome */}
            <div className="space-y-2 md:col-span-2">
              <Label>Nome do Produto *</Label>
              <Input value={form.name} onChange={e => update("name", e.target.value)} required placeholder="Ex: Pão de hambúrguer" />
            </div>

            {/* SKU e Categoria */}
            <div className="space-y-2">
              <Label>SKU</Label>
              <Input value={form.sku} onChange={e => update("sku", e.target.value)} placeholder="Ex: PAO-001" />
            </div>
            <div className="space-y-2">
              <Label>Categoria *</Label>
              <Select value={form.category} onValueChange={v => update("category", v)}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  {categories.map(c => <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Quantidades */}
            <div className="space-y-2">
              <Label>Quantidade *</Label>
              <Input type="number" min="0" value={form.quantity} onChange={e => update("quantity", Number(e.target.value))} required />
            </div>
            <div className="space-y-2">
              <Label>Qtd. Mínima</Label>
              <Input type="number" min="0" value={form.min_quantity} onChange={e => update("min_quantity", Number(e.target.value))} />
            </div>
            <div className="space-y-2">
              <Label>Qtd. Ideal</Label>
              <Input type="number" min="0" value={form.ideal_quantity} onChange={e => update("ideal_quantity", Number(e.target.value))} placeholder="Meta mensal" />
            </div>

            {/* Preço e Unidade */}
            <div className="space-y-2">
              <Label>Valor Unitário (R$) *</Label>
              <Input type="number" min="0" step="0.01" value={form.unit_price} onChange={e => update("unit_price", Number(e.target.value))} required />
            </div>
            <div className="space-y-2">
              <Label>Unidade</Label>
              <Select value={form.unit} onValueChange={v => update("unit", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {units.map(u => <SelectItem key={u.value} value={u.value}>{u.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            {/* Fornecedor e Localização */}
            <div className="space-y-2">
              <Label>Fornecedor</Label>
              <Select value={form.supplier_name || "_none"} onValueChange={v => update("supplier_name", v === "_none" ? "" : v)}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">Nenhum</SelectItem>
                  {suppliers.map(s => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Localização</Label>
              <Input value={form.location} onChange={e => update("location", e.target.value)} placeholder="Ex: Prateleira A3" />
            </div>

            {/* Tipos de cozinha */}
            {allKitchenTypes.length > 0 && (
              <div className="md:col-span-2 space-y-2 pt-2 border-t border-slate-100 dark:border-slate-700">
                <Label>Tipos de Cozinha</Label>
                <p className="text-xs text-slate-500 dark:text-slate-400">Associe este produto aos tipos de cozinha das suas lojas</p>
                <div className="flex flex-wrap gap-3">
                  {allKitchenTypes.map(type => (
                    <label key={type} className="flex items-center gap-2 cursor-pointer select-none">
                      <Checkbox
                        checked={(form.kitchen_types || []).includes(type)}
                        onCheckedChange={() => toggleKitchenType(type)}
                      />
                      <span className="text-sm capitalize">{type}</span>
                    </label>
                  ))}
                </div>
              </div>
            )}

            {/* Contagem por caixa */}
            <div className="md:col-span-2 pt-2 border-t border-slate-100 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Contagem por embalagem?</Label>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Ative para produtos contados por caixas, fardos, etc.</p>
                </div>
                <Switch
                  checked={form.has_box_counting}
                  onCheckedChange={v => update("has_box_counting", v)}
                />
              </div>

              {form.has_box_counting && (
                <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700">
                  <div className="space-y-2">
                    <Label>Nome da embalagem</Label>
                    <Input value={form.box_unit_label} onChange={e => update("box_unit_label", e.target.value)} placeholder="Ex: caixa, fardo, pacote" />
                  </div>
                  <div className="space-y-2">
                    <Label>Unidades por embalagem</Label>
                    <Input type="number" min="1" value={form.units_per_box} onChange={e => update("units_per_box", Number(e.target.value))} />
                  </div>
                  <div className="col-span-2 text-xs text-slate-500 dark:text-slate-400 bg-blue-50 dark:bg-blue-900/20 rounded-lg px-3 py-2">
                    Exemplo: 1 {form.box_unit_label || "caixa"} = {form.units_per_box || 1} {form.unit || "unidade"}(s)
                  </div>
                </div>
              )}
            </div>

            {/* Notas */}
            <div className="space-y-2 md:col-span-2">
              <Label>Observações</Label>
              <Textarea value={form.notes} onChange={e => update("notes", e.target.value)} rows={2} placeholder="Notas adicionais..." />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={saving} className="bg-[#1e3a5f] hover:bg-[#2d5a8e]">
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {product ? "Salvar Alterações" : "Cadastrar Produto"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}