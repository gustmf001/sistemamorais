import React, { useState, useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Plus, X } from "lucide-react";

const DEFAULT_KITCHEN_TYPES = [
  { value: "pizzaria", label: "🍕 Pizzaria" },
  { value: "hamburgueria", label: "🍔 Hamburgueria" },
  { value: "açaiteria", label: "🍇 Açaiteria" },
  { value: "browneria", label: "🍫 Browneria" },
];

const emptyForm = { name: "", kitchen_types: [], active: true, notes: "" };

export default function StoreFormDialog({ open, onOpenChange, store, onSave }) {
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [customType, setCustomType] = useState("");

  // Collect all kitchen types: defaults + any custom ones from the store
  const allTypes = React.useMemo(() => {
    const defaultValues = DEFAULT_KITCHEN_TYPES.map(t => t.value);
    const extras = (form.kitchen_types || []).filter(t => !defaultValues.includes(t));
    return [
      ...DEFAULT_KITCHEN_TYPES,
      ...extras.map(t => ({ value: t, label: `✏️ ${t}` })),
    ];
  }, [form.kitchen_types]);

  useEffect(() => {
    if (store) {
      // Support migration from old kitchen_type (string) to kitchen_types (array)
      const types = store.kitchen_types?.length
        ? store.kitchen_types
        : store.kitchen_type ? [store.kitchen_type] : [];
      setForm({ ...emptyForm, ...store, kitchen_types: types });
    } else {
      setForm(emptyForm);
    }
    setCustomType("");
  }, [store, open]);

  const toggleType = (value) => {
    setForm(prev => {
      const current = prev.kitchen_types || [];
      const has = current.includes(value);
      return { ...prev, kitchen_types: has ? current.filter(t => t !== value) : [...current, value] };
    });
  };

  const addCustomType = () => {
    const trimmed = customType.trim().toLowerCase();
    if (!trimmed) return;
    if (!(form.kitchen_types || []).includes(trimmed)) {
      setForm(prev => ({ ...prev, kitchen_types: [...(prev.kitchen_types || []), trimmed] }));
    }
    setCustomType("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || (form.kitchen_types || []).length === 0) return;
    setSaving(true);
    await onSave({ ...form });
    setSaving(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{store ? "Editar Loja" : "Nova Loja"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-2">
            <Label>Nome da Loja *</Label>
            <Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} required placeholder="Ex: Loja Realengo" />
          </div>

          <div className="space-y-2">
            <Label>Segmentos da Loja *</Label>
            <p className="text-xs text-slate-500 dark:text-slate-400">Selecione todos os tipos de cozinha que esta loja possui</p>
            <div className="grid grid-cols-2 gap-2">
              {allTypes.map(type => (
                <label key={type.value} className="flex items-center gap-2.5 p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                  <Checkbox
                    checked={(form.kitchen_types || []).includes(type.value)}
                    onCheckedChange={() => toggleType(type.value)}
                  />
                  <span className="text-sm">{type.label}</span>
                </label>
              ))}
            </div>

            {/* Add custom type */}
            <div className="flex gap-2 mt-2">
              <Input
                placeholder="Outro tipo (ex: susheria)"
                value={customType}
                onChange={e => setCustomType(e.target.value)}
                onKeyDown={e => e.key === "Enter" && (e.preventDefault(), addCustomType())}
                className="text-sm"
              />
              <Button type="button" variant="outline" size="sm" onClick={addCustomType} disabled={!customType.trim()}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {(form.kitchen_types || []).length === 0 && (
              <p className="text-xs text-red-500">Selecione pelo menos um segmento.</p>
            )}
          </div>

          <div className="space-y-2">
            <Label>Observações</Label>
            <Textarea value={form.notes} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} rows={2} placeholder="Notas sobre a loja..." />
          </div>

          <div className="flex items-center justify-between py-2">
            <Label htmlFor="store-active">Loja ativa</Label>
            <Switch id="store-active" checked={form.active !== false} onCheckedChange={v => setForm(p => ({ ...p, active: v }))} />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={saving || (form.kitchen_types || []).length === 0} className="bg-[#1e3a5f] hover:bg-[#2d5a8e]">
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {store ? "Salvar" : "Cadastrar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}