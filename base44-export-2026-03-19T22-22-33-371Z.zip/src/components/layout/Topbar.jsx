const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";
import { Button } from "@/components/ui/button";
import { Menu, Sun, Moon, LogOut } from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { usePermissions } from "@/components/auth/usePermissions";

export default function Topbar({ onMenuOpen, darkMode, onToggleDark }) {
  const currentUser = usePermissions().user;
  const handleLogout = () => db.auth.logout();

  return (
    <header className="h-16 bg-card border-b border-border px-4 flex items-center justify-between sticky top-0 z-30">
      <button
        onClick={onMenuOpen}
        className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors"
      >
        <Menu className="w-5 h-5 text-foreground" />
      </button>
      <div className="hidden lg:block" />

      <div className="flex items-center gap-2">
        {/* Theme toggle */}
        <button
          onClick={onToggleDark}
          title={darkMode ? "Mudar para tema Claro (Vermelho)" : "Mudar para tema Escuro (Amarelo)"}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-border hover:bg-muted transition-colors text-xs font-medium text-muted-foreground"
        >
          {darkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          <span className="hidden sm:inline">{darkMode ? "Claro" : "Escuro"}</span>
        </button>

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl hover:bg-muted transition-colors">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-sm font-semibold">
                {(currentUser?.full_name || currentUser?.email || "?")[0].toUpperCase()}
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-sm font-medium text-foreground leading-none">
                  {currentUser?.full_name || "Usuário"}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5 capitalize">
                  {currentUser?.role === "admin" ? "Admin" : "Operador"}
                </p>
              </div>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuItem className="text-xs text-muted-foreground cursor-default" disabled>
              {currentUser?.email}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="text-destructive">
              <LogOut className="w-4 h-4 mr-2" /> Sair
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}