import React, { useState, useEffect } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Loader2 } from "lucide-react";
import { format } from "date-fns";

const emptyForm = {
  type: "compra", order_number: "", status: "rascunho",
  supplier_name: "", customer_name: "", customer_contact: "",
  order_date: format(new Date(), "yyyy-MM-dd"), expected_date: "",
  items: [], total_value: 0, notes: "",
};

export default function OrderFormDialog({ open, onOpenChange, order, products, suppliers, onSave }) {
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setForm(order ? { ...emptyForm, ...order, items: order.items || [] } : emptyForm);
    }
  }, [open, order]);

  const update = (field, value) => setForm(prev => ({ ...prev, [field]: value }));

  const addItem = () => {
    setForm(prev => ({
      ...prev,
      items: [...prev.items, { product_id: "", product_name: "", quantity: 1, unit_price: 0, total: 0 }],
    }));
  };

  const updateItem = (index, field, value) => {
    setForm(prev => {
      const items = [...prev.items];
      items[index] = { ...items[index], [field]: value };

      if (field === "product_id") {
        const product = products.find(p => p.id === value);
        if (product) {
          items[index].product_name = product.name;
          items[index].unit_price = product.unit_price || 0;
          items[index].total = items[index].quantity * (product.unit_price || 0);
        }
      }
      if (field === "quantity" || field === "unit_price") {
        const qty = field === "quantity" ? Number(value) : items[index].quantity;
        const price = field === "unit_price" ? Number(value) : items[index].unit_price;
        items[index].total = qty * price;
        if (field === "quantity") items[index].quantity = Number(value);
        if (field === "unit_price") items[index].unit_price = Number(value);
      }

      const total_value = items.reduce((sum, i) => sum + (i.total || 0), 0);
      return { ...prev, items, total_value };
    });
  };

  const removeItem = (index) => {
    setForm(prev => {
      const items = prev.items.filter((_, i) => i !== index);
      const total_value = items.reduce((sum, i) => sum + (i.total || 0), 0);
      return { ...prev, items, total_value };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSave(form);
    setSaving(false);
    onOpenChange(false);
  };

  const isCompra = form.type === "compra";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{order ? "Editar Pedido" : "Novo Pedido"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Cabeçalho */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Tipo *</Label>
              <Select value={form.type} onValueChange={v => update("type", v)} disabled={!!order}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="compra">Pedido de Compra</SelectItem>
                  <SelectItem value="venda">Pedido de Venda</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Número do Pedido</Label>
              <Input value={form.order_number} onChange={e => update("order_number", e.target.value)} placeholder="PED-001" />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => update("status", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="rascunho">Rascunho</SelectItem>
                  <SelectItem value="confirmado">Confirmado</SelectItem>
                  <SelectItem value="em_andamento">Em Andamento</SelectItem>
                  <SelectItem value="concluido">Concluído</SelectItem>
                  <SelectItem value="cancelado">Cancelado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {isCompra ? (
              <div className="space-y-2 col-span-2 md:col-span-3">
                <Label>Fornecedor</Label>
                <Select value={form.supplier_name || "_none"} onValueChange={v => update("supplier_name", v === "_none" ? "" : v)}>
                  <SelectTrigger><SelectValue placeholder="Selecione o fornecedor" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="_none">Nenhum</SelectItem>
                    {suppliers.map(s => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <>
                <div className="space-y-2 col-span-2">
                  <Label>Cliente</Label>
                  <Input value={form.customer_name} onChange={e => update("customer_name", e.target.value)} placeholder="Nome do cliente" />
                </div>
                <div className="space-y-2">
                  <Label>Contato</Label>
                  <Input value={form.customer_contact} onChange={e => update("customer_contact", e.target.value)} placeholder="Telefone ou email" />
                </div>
              </>
            )}
            <div className="space-y-2">
              <Label>Data do Pedido *</Label>
              <Input type="date" value={form.order_date} onChange={e => update("order_date", e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label>Previsão de {isCompra ? "Recebimento" : "Entrega"}</Label>
              <Input type="date" value={form.expected_date} onChange={e => update("expected_date", e.target.value)} />
            </div>
          </div>

          {/* Itens */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-sm font-semibold text-slate-700">Itens do Pedido</Label>
              <Button type="button" size="sm" variant="outline" onClick={addItem}>
                <Plus className="w-4 h-4 mr-1" /> Adicionar Item
              </Button>
            </div>
            <div className="space-y-2">
              {form.items.length === 0 && (
                <p className="text-sm text-slate-400 text-center py-4 border-2 border-dashed border-slate-200 rounded-xl">
                  Nenhum item adicionado. Clique em "Adicionar Item".
                </p>
              )}
              {form.items.map((item, index) => (
                <div key={index} className="grid grid-cols-12 gap-2 items-end p-3 bg-slate-50 rounded-xl">
                  <div className="col-span-5 space-y-1">
                    <Label className="text-xs">Produto</Label>
                    <Select value={item.product_id || "_none"} onValueChange={v => updateItem(index, "product_id", v === "_none" ? "" : v)}>
                      <SelectTrigger className="h-9 text-sm"><SelectValue placeholder="Selecione" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="_none">Selecione...</SelectItem>
                        {products.filter(p => p.status === "ativo").map(p => (
                          <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-2 space-y-1">
                    <Label className="text-xs">Qtd.</Label>
                    <Input className="h-9 text-sm" type="number" min="1" value={item.quantity}
                      onChange={e => updateItem(index, "quantity", e.target.value)} />
                  </div>
                  <div className="col-span-2 space-y-1">
                    <Label className="text-xs">Valor Unit.</Label>
                    <Input className="h-9 text-sm" type="number" min="0" step="0.01" value={item.unit_price}
                      onChange={e => updateItem(index, "unit_price", e.target.value)} />
                  </div>
                  <div className="col-span-2 space-y-1">
                    <Label className="text-xs">Total</Label>
                    <Input className="h-9 text-sm bg-white" value={`R$ ${(item.total || 0).toFixed(2)}`} readOnly />
                  </div>
                  <div className="col-span-1 flex justify-end">
                    <Button type="button" variant="ghost" size="icon" className="h-9 w-9 text-red-400 hover:text-red-600"
                      onClick={() => removeItem(index)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            {form.items.length > 0 && (
              <div className="flex justify-end mt-3 pr-1">
                <p className="text-sm font-bold text-slate-800">
                  Total: R$ {(form.total_value || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </p>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label>Observações</Label>
            <Textarea value={form.notes} onChange={e => update("notes", e.target.value)} rows={2} placeholder="Notas adicionais..." />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={saving} className="bg-[#1e3a5f] hover:bg-[#2d5a8e]">
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {order ? "Salvar Alterações" : "Criar Pedido"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}