import React from "react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const statusConfig = {
  rascunho: { label: "Rascunho", class: "bg-slate-100 text-slate-600 border-slate-200" },
  confirmado: { label: "Confirmado", class: "bg-blue-50 text-blue-700 border-blue-200" },
  em_andamento: { label: "Em Andamento", class: "bg-amber-50 text-amber-700 border-amber-200" },
  concluido: { label: "Concluído", class: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  cancelado: { label: "Cancelado", class: "bg-red-50 text-red-600 border-red-200" },
};

export default function OrderStatusBadge({ status }) {
  const config = statusConfig[status] || statusConfig.rascunho;
  return (
    <Badge variant="outline" className={cn("font-medium", config.class)}>
      {config.label}
    </Badge>
  );
}