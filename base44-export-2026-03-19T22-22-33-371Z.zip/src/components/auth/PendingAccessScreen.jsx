const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";
import { Clock, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";

const LOGO_URL = "https://media.db.com/images/public/69ba0915910a22001f6bf92b/3cba5cae7_LOGOMORAISINSTITUICAO.png";

export default function PendingAccessScreen() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6">
      <div className="text-center space-y-6 max-w-md">
        <img src={LOGO_URL} alt="O Morais" className="w-24 h-24 rounded-2xl object-cover mx-auto shadow-lg" />
        <div>
          <h1 className="text-2xl font-bold text-foreground">Acesso Pendente</h1>
          <p className="text-muted-foreground mt-2">
            Seu cadastro está aguardando autorização do administrador. Em breve você receberá acesso ao sistema.
          </p>
        </div>
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-xl p-4 flex items-center gap-3">
          <Clock className="w-5 h-5 text-amber-600 shrink-0" />
          <p className="text-sm text-amber-700 dark:text-amber-300">
            Entre em contato com o responsável para solicitar liberação do seu perfil.
          </p>
        </div>
        <Button variant="outline" onClick={() => db.auth.logout()} className="gap-2">
          <LogOut className="w-4 h-4" />
          Sair
        </Button>
      </div>
    </div>
  );
}