const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";

import { Loader2 } from "lucide-react";
import PendingAccessScreen from "./PendingAccessScreen";

export default function RouteGuard({ children }) {
  const [status, setStatus] = useState("loading"); // loading | ok | pending | unauthenticated

  useEffect(() => {
    db.auth.isAuthenticated().then(async (auth) => {
      if (!auth) {
        setStatus("unauthenticated");
        db.auth.redirectToLogin(window.location.href);
      } else {
        const user = await db.auth.me().catch(() => null);
        if (user?.role === "pending") {
          setStatus("pending");
        } else {
          setStatus("ok");
        }
      }
    });
  }, []);

  if (status === "loading" || status === "unauthenticated") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (status === "pending") {
    return <PendingAccessScreen />;
  }

  return children;
}