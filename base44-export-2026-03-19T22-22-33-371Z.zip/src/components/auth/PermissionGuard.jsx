import React from "react";
import { Shield } from "lucide-react";
import { usePermissions } from "./usePermissions";

/**
 * Renders children only if user has the required role.
 * If not, shows an access denied screen (or nothing if silent=true).
 */
export default function PermissionGuard({ requiredRole = "admin", silent = false, children }) {
  const { user, isAdmin } = usePermissions();

  // still loading
  if (!user) return null;

  const allowed = requiredRole === "admin" ? isAdmin : true;

  if (!allowed) {
    if (silent) return null;
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
        <div className="w-16 h-16 rounded-2xl bg-red-50 dark:bg-red-950 flex items-center justify-center mb-4">
          <Shield className="w-8 h-8 text-red-400" />
        </div>
        <h2 className="text-xl font-bold text-slate-700 dark:text-slate-200">Acesso Restrito</h2>
        <p className="text-slate-500 dark:text-slate-400 mt-2 max-w-sm">
          Você não tem permissão para acessar esta página. Apenas administradores podem visualizá-la.
        </p>
      </div>
    );
  }

  return children;
}