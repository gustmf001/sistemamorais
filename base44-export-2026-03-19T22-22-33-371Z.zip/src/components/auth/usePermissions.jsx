const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useCallback } from "react";

// Simple event bus to notify all usePermissions instances to reload
const listeners = new Set();
export function clearPermissionsCache() {
  listeners.forEach(fn => fn());
}

export function usePermissions() {
  const [user, setUser] = useState(null);
  const [roles, setRoles] = useState([]);
  const [loaded, setLoaded] = useState(false);

  const reload = useCallback(() => {
    setLoaded(false);
    Promise.all([
      db.auth.me().catch(() => null),
      db.entities.Role.list().catch(() => []),
    ]).then(([u, r]) => {
      setUser(u);
      setRoles(r);
      setLoaded(true);
    });
  }, []);

  useEffect(() => {
    reload();
    listeners.add(reload);
    return () => listeners.delete(reload);
  }, [reload]);

  const isAdmin = user?.role === "admin";
  const isPending = user?.role === "pending";

  // Find matching custom role
  const userRoleData = !isAdmin && !isPending && user?.role
    ? roles.find(r => r.name === user.role)
    : null;

  // null = all pages allowed (admin or legacy "user" role)
  const allowedPages = isAdmin
    ? null
    : userRoleData
      ? (userRoleData.pages || [])
      : (user?.role === "user" ? null : null); // legacy "user" = all access

  const canAccessPage = (pageName) => {
    if (!loaded) return true;
    if (isAdmin) return true;
    if (isPending) return false;
    if (allowedPages === null) return true;
    return allowedPages.includes(pageName);
  };

  const isOperator = !isAdmin && !isPending && !!user;

  const can = (action) => {
    if (!loaded || isPending) return false;
    if (isAdmin) return true;
    const adminOnly = ["delete_products", "manual_stock", "manage_users", "delete_orders"];
    return !adminOnly.includes(action);
  };

  return { user, isAdmin, isOperator, isPending, allowedPages, canAccessPage, loaded, roles, can };
}