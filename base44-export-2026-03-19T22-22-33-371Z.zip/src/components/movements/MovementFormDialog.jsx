import React, { useState, useEffect } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, Trash2, AlertTriangle } from "lucide-react";
import { format } from "date-fns";

const emptyItem = () => ({ product_id: "", product_name: "", quantity: 1, unit_price: 0, total_value: 0, boxes: "", extra_units: "" });

export default function MovementFormDialog({ open, onOpenChange, products, suppliers, sectors = [], onSave }) {
  const [type, setType] = useState("entrada");
  const [movementDate, setMovementDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [supplierName, setSupplierName] = useState("");
  const [destinationSector, setDestinationSector] = useState("");
  const [reason, setReason] = useState("");
  const [notes, setNotes] = useState("");
  const [items, setItems] = useState([emptyItem()]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setType("entrada");
      setMovementDate(format(new Date(), "yyyy-MM-dd"));
      setSupplierName("");
      setDestinationSector("");
      setReason("");
      setNotes("");
      setItems([emptyItem()]);
    }
  }, [open]);

  const calcBoxQuantity = (item, product) => {
    if (!product?.has_box_counting) return null;
    const boxes = Number(item.boxes) || 0;
    const extra = Number(item.extra_units) || 0;
    const unitsPerBox = Number(product.units_per_box) || 1;
    return boxes * unitsPerBox + extra;
  };

  const updateItem = (index, field, value) => {
    setItems(prev => prev.map((item, i) => {
      if (i !== index) return item;
      const next = { ...item, [field]: value };
      if (field === "product_id") {
        const product = products.find(p => p.id === value);
        if (product) {
          next.product_name = product.name;
          next.unit_price = product.unit_price || 0;
          next.boxes = "";
          next.extra_units = "";
          const qty = product.has_box_counting ? 0 : 1;
          next.quantity = qty;
          next.total_value = (product.unit_price || 0) * qty;
        }
      }
      // Box counting recalc
      if (field === "boxes" || field === "extra_units") {
        const product = products.find(p => p.id === next.product_id);
        if (product?.has_box_counting) {
          const boxVal = field === "boxes" ? Number(value) : Number(next.boxes);
          const extraVal = field === "extra_units" ? Number(value) : Number(next.extra_units);
          const total = boxVal * (product.units_per_box || 1) + extraVal;
          next.quantity = total;
          next.total_value = total * (next.unit_price || 0);
        }
      }
      if (field === "quantity" || field === "unit_price") {
        const qty = field === "quantity" ? Number(value) : Number(next.quantity);
        const price = field === "unit_price" ? Number(value) : Number(next.unit_price);
        next.total_value = qty * price;
      }
      return next;
    }));
  };

  const addItem = () => setItems(prev => [...prev, emptyItem()]);
  const removeItem = (index) => setItems(prev => prev.filter((_, i) => i !== index));

  const getStockError = (item) => {
    if (type !== "saida" || !item.product_id) return null;
    const product = products.find(p => p.id === item.product_id);
    if (!product) return null;
    if (Number(item.quantity) > (product.quantity || 0)) {
      return `Estoque insuficiente (${product.quantity || 0} disponíveis)`;
    }
    return null;
  };

  const hasErrors = items.some(item => getStockError(item));
  const allItemsValid = items.every(item => item.product_id && Number(item.quantity) > 0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (hasErrors || !allItemsValid) return;
    setSaving(true);
    for (const item of items) {
      await onSave({
        product_id: item.product_id,
        product_name: item.product_name,
        type,
        quantity: Number(item.quantity),
        unit_price: Number(item.unit_price),
        total_value: Number(item.total_value),
        supplier_name: supplierName,
        destination_sector: destinationSector,
        movement_date: movementDate,
        reason,
        notes,
      });
    }
    setSaving(false);
    onOpenChange(false);
  };

  const grandTotal = items.reduce((sum, item) => sum + Number(item.total_value || 0), 0);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nova Movimentação</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-5">

          {/* Header fields */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Tipo *</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="entrada">Entrada</SelectItem>
                  <SelectItem value="saida">Saída</SelectItem>
                  <SelectItem value="ajuste">Ajuste</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Data *</Label>
              <Input type="date" value={movementDate} onChange={e => setMovementDate(e.target.value)} required />
            </div>
            <div className="space-y-2">
              <Label>Setor de Destino</Label>
              <Select value={destinationSector || "_none"} onValueChange={v => setDestinationSector(v === "_none" ? "" : v)}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">Não informado</SelectItem>
                  {sectors.filter(s => s.active !== false).map(s => (
                    <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {type === "entrada" && (
            <div className="space-y-2">
              <Label>Fornecedor</Label>
              <Select value={supplierName || "_none"} onValueChange={v => setSupplierName(v === "_none" ? "" : v)}>
                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">Nenhum</SelectItem>
                  {suppliers.map(s => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}

          {/* Products list */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold">Produtos *</Label>
              <Button type="button" variant="outline" size="sm" onClick={addItem} className="gap-1.5">
                <Plus className="w-4 h-4" /> Adicionar Produto
              </Button>
            </div>

            <div className="space-y-2">
              {items.map((item, index) => {
                const stockError = getStockError(item);
                const selectedProduct = products.find(p => p.id === item.product_id);
                const isBoxCounting = selectedProduct?.has_box_counting;
                return (
                  <div key={index} className="border border-slate-200 dark:border-slate-700 rounded-xl p-3 space-y-2 bg-slate-50/50 dark:bg-slate-800/50">
                    <div className="flex items-center gap-2 flex-wrap">
                      <div className="flex-1 min-w-[180px]">
                        <Select value={item.product_id} onValueChange={v => updateItem(index, "product_id", v)}>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o produto" />
                          </SelectTrigger>
                          <SelectContent>
                            {products.filter(p => p.status === "ativo").map(p => (
                              <SelectItem key={p.id} value={p.id}>
                                {p.name} <span className="text-slate-400 text-xs ml-1">({p.quantity} em estoque)</span>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      {!isBoxCounting && (
                        <div className="w-28">
                          <Input
                            type="number" min="1" placeholder="Qtd."
                            value={item.quantity}
                            onChange={e => updateItem(index, "quantity", e.target.value)}
                          />
                        </div>
                      )}
                      <div className="w-32">
                        <Input
                          type="number" min="0" step="0.01" placeholder="R$ Unit."
                          value={item.unit_price}
                          onChange={e => updateItem(index, "unit_price", e.target.value)}
                        />
                      </div>
                      <div className="w-28 text-right text-sm font-semibold text-slate-700 dark:text-slate-200">
                        R$ {Number(item.total_value).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                      </div>
                      {items.length > 1 && (
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(index)} className="text-red-500 hover:text-red-700 hover:bg-red-50">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>

                    {/* Box counting section */}
                    {isBoxCounting && item.product_id && (
                      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-lg p-3 space-y-2">
                        <p className="text-xs font-semibold text-amber-800 dark:text-amber-300">
                          Contagem por {selectedProduct.box_unit_label || "caixa"} — 1 {selectedProduct.box_unit_label || "caixa"} = {selectedProduct.units_per_box || 1} {selectedProduct.unit || "unidade"}(s)
                        </p>
                        <div className="flex items-center gap-3">
                          <div className="flex-1 space-y-1">
                            <label className="text-xs text-amber-700 dark:text-amber-400">Quantas {selectedProduct.box_unit_label || "caixa"}s?</label>
                            <Input
                              type="number" min="0" placeholder="0"
                              value={item.boxes}
                              onChange={e => updateItem(index, "boxes", e.target.value)}
                              className="bg-white dark:bg-slate-800"
                            />
                          </div>
                          <div className="flex-1 space-y-1">
                            <label className="text-xs text-amber-700 dark:text-amber-400">Unidades avulsas além das {selectedProduct.box_unit_label || "caixa"}s?</label>
                            <Input
                              type="number" min="0" placeholder="0"
                              value={item.extra_units}
                              onChange={e => updateItem(index, "extra_units", e.target.value)}
                              className="bg-white dark:bg-slate-800"
                            />
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-amber-600 dark:text-amber-400">Total</p>
                            <p className="text-lg font-bold text-amber-800 dark:text-amber-200">{item.quantity || 0}</p>
                            <p className="text-xs text-amber-600">{selectedProduct.unit || "un"}</p>
                          </div>
                        </div>
                      </div>
                    )}

                    {stockError && (
                      <div className="flex items-center gap-1.5 text-xs text-red-600">
                        <AlertTriangle className="w-3.5 h-3.5" /> {stockError}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {items.length > 1 && (
              <div className="flex justify-end pt-1">
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                  Total geral: R$ {grandTotal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                </span>
              </div>
            )}
          </div>

          {/* Footer fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Motivo</Label>
              <Input value={reason} onChange={e => setReason(e.target.value)} placeholder="Ex: Compra mensal, Uso em produção..." />
            </div>
            <div className="space-y-2">
              <Label>Observações</Label>
              <Textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={saving || !allItemsValid || hasErrors} className="bg-[#1e3a5f] hover:bg-[#2d5a8e]">
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Registrar {items.length > 1 ? `(${items.length} produtos)` : ""}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}