import React, { useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { TrendingUp, TrendingDown } from "lucide-react";

const COLORS_HIGH = "#1e3a5f";
const COLORS_LOW = "#94a3b8";

export default function ProductUsageChart({ movements }) {
  const [view, setView] = useState("mais"); // "mais" | "menos"

  const usageData = useMemo(() => {
    const map = {};
    movements
      .filter(m => m.type === "saida")
      .forEach(m => {
        if (!map[m.product_name]) map[m.product_name] = 0;
        map[m.product_name] += m.quantity || 0;
      });

    const sorted = Object.entries(map)
      .map(([name, qty]) => ({ name, qty }))
      .sort((a, b) => view === "mais" ? b.qty - a.qty : a.qty - b.qty)
      .slice(0, 8);

    return sorted;
  }, [movements, view]);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/60 p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-slate-800">Uso dos Produtos</h3>
          <p className="text-xs text-slate-400 mt-0.5">Saídas registradas no histórico</p>
        </div>
        <div className="flex rounded-lg border border-slate-200 overflow-hidden text-xs">
          <button
            onClick={() => setView("mais")}
            className={`flex items-center gap-1.5 px-3 py-2 transition-colors ${
              view === "mais" ? "bg-[#1e3a5f] text-white" : "text-slate-500 hover:bg-slate-50"
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" /> Mais saídas
          </button>
          <button
            onClick={() => setView("menos")}
            className={`flex items-center gap-1.5 px-3 py-2 transition-colors ${
              view === "menos" ? "bg-[#1e3a5f] text-white" : "text-slate-500 hover:bg-slate-50"
            }`}
          >
            <TrendingDown className="w-3.5 h-3.5" /> Menos saídas
          </button>
        </div>
      </div>

      {usageData.length === 0 ? (
        <div className="flex items-center justify-center h-40 text-slate-400 text-sm">
          Nenhuma saída registrada ainda
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={usageData} layout="vertical" margin={{ left: 0, right: 20, top: 0, bottom: 0 }}>
            <XAxis type="number" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
            <YAxis
              dataKey="name"
              type="category"
              width={120}
              tick={{ fontSize: 11, fill: "#475569" }}
              axisLine={false}
              tickLine={false}
              tickFormatter={v => v.length > 18 ? v.slice(0, 18) + "…" : v}
            />
            <Tooltip
              formatter={(val) => [`${val} unid.`, "Saídas"]}
              contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e2e8f0" }}
            />
            <Bar dataKey="qty" radius={[0, 6, 6, 0]}>
              {usageData.map((_, i) => (
                <Cell key={i} fill={i === 0 ? COLORS_HIGH : i < 3 ? "#2d5a8e" : COLORS_LOW} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      )}

      {usageData.length > 0 && (
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="bg-slate-50 rounded-xl p-3">
            <p className="text-xs text-slate-400">
              {view === "mais" ? "Produto mais consumido" : "Produto menos consumido"}
            </p>
            <p className="font-semibold text-slate-800 text-sm mt-1 truncate">{usageData[0]?.name}</p>
            <p className="text-xs text-slate-500">{usageData[0]?.qty} saídas</p>
          </div>
          <div className="bg-slate-50 rounded-xl p-3">
            <p className="text-xs text-slate-400">Total de saídas (top 8)</p>
            <p className="font-semibold text-slate-800 text-sm mt-1">
              {usageData.reduce((s, d) => s + d.qty, 0)} unidades
            </p>
          </div>
        </div>
      )}
    </div>
  );
}