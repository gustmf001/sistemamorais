import React from "react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { ArrowDownLeft, ArrowUpRight, RefreshCw, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { cn } from "@/lib/utils";

const typeConfig = {
  entrada: { icon: ArrowDownLeft, color: "text-emerald-600", bg: "bg-emerald-50", label: "Entrada" },
  saida: { icon: ArrowUpRight, color: "text-red-500", bg: "bg-red-50", label: "Saída" },
  ajuste: { icon: RefreshCw, color: "text-blue-500", bg: "bg-blue-50", label: "Ajuste" },
};

export default function RecentMovements({ movements }) {
  const recent = movements.slice(0, 8);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/60 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-slate-800">Movimentações Recentes</h3>
        <Link
          to={createPageUrl("Movements")}
          className="text-sm text-[#1e3a5f] font-medium hover:underline flex items-center gap-1"
        >
          Ver todas <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {recent.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center mb-3">
            <ArrowLeftRight className="w-7 h-7 text-slate-300" />
          </div>
          <p className="text-sm text-slate-500">Nenhuma movimentação registrada</p>
        </div>
      ) : (
        <div className="space-y-2">
          {recent.map((mov) => {
            const config = typeConfig[mov.type] || typeConfig.ajuste;
            const Icon = config.icon;
            return (
              <div key={mov.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors">
                <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0", config.bg)}>
                  <Icon className={cn("w-4 h-4", config.color)} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800 truncate">{mov.product_name}</p>
                  <p className="text-xs text-slate-400">
                    {mov.movement_date ? format(new Date(mov.movement_date), "dd MMM yyyy", { locale: ptBR }) : "—"}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className={cn("text-sm font-bold", config.color)}>
                    {mov.type === "entrada" ? "+" : mov.type === "saida" ? "-" : "±"}{mov.quantity}
                  </p>
                  {mov.total_value > 0 && (
                    <p className="text-xs text-slate-400">
                      R$ {mov.total_value.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ArrowLeftRight(props) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
      <path d="M8 3L4 7l4 4"/><path d="M4 7h16"/><path d="m16 21 4-4-4-4"/><path d="M20 17H4"/>
    </svg>
  );
}