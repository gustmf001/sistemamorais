import React from "react";
import { AlertTriangle, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { cn } from "@/lib/utils";

export default function LowStockAlert({ products }) {
  const lowStockProducts = products.filter(p => p.status === "ativo" && p.quantity <= p.min_quantity);

  if (lowStockProducts.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Alertas de Estoque</h3>
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 flex items-center justify-center mb-3">
            <AlertTriangle className="w-7 h-7 text-emerald-500" />
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400">Nenhum produto com estoque baixo</p>
          <p className="text-xs text-slate-400 dark:text-slate-500 mt-1">Todos os produtos estão dentro do nível mínimo</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/60 dark:border-slate-700 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-slate-800 dark:text-slate-100">Alertas de Estoque</h3>
        <span className="px-2.5 py-1 rounded-full bg-red-50 text-red-600 text-xs font-semibold">
          {lowStockProducts.length} {lowStockProducts.length === 1 ? "produto" : "produtos"}
        </span>
      </div>
      <div className="space-y-3 max-h-[400px] overflow-y-auto pr-1">
        {lowStockProducts.map((product) => {
          const percentage = product.min_quantity > 0 ? (product.quantity / product.min_quantity) * 100 : 0;
          const isZero = product.quantity === 0;
          return (
            <div
              key={product.id}
              className={cn(
                "rounded-xl p-4 border transition-all",
                isZero
                  ? "bg-red-50/50 border-red-200"
                  : "bg-amber-50/50 border-amber-200"
              )}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="font-semibold text-slate-800 text-sm">{product.name}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{product.sku || "Sem SKU"}</p>
                </div>
                <div className="text-right">
                  <p className={cn("text-lg font-bold", isZero ? "text-red-600" : "text-amber-600")}>
                    {product.quantity}
                  </p>
                  <p className="text-xs text-slate-400">mín: {product.min_quantity}</p>
                </div>
              </div>
              <div className="mt-3">
                <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className={cn("h-full rounded-full transition-all", isZero ? "bg-red-500" : "bg-amber-500")}
                    style={{ width: `${Math.min(percentage, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <Link
        to={createPageUrl("Products")}
        className="flex items-center justify-center gap-2 mt-4 py-2.5 rounded-xl text-sm font-medium text-[#1e3a5f] hover:bg-slate-50 transition-colors"
      >
        Ver todos os produtos <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
}