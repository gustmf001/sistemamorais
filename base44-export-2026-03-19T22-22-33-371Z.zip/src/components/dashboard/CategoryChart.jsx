import React from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const COLORS = ["#1e3a5f", "#2d5a8e", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899", "#06b6d4"];

const categoryLabels = {
  materia_prima: "Matéria Prima",
  produto_acabado: "Produto Acabado",
  embalagem: "Embalagem",
  insumo: "Insumo",
  ferramenta: "Ferramenta",
  escritorio: "Escritório",
  limpeza: "Limpeza",
  outro: "Outro",
};

export default function CategoryChart({ products }) {
  const categoryData = products.reduce((acc, p) => {
    const cat = p.category || "outro";
    const label = categoryLabels[cat] || cat;
    const existing = acc.find(a => a.name === label);
    if (existing) {
      existing.value += 1;
      existing.total += (p.quantity || 0) * (p.unit_price || 0);
    } else {
      acc.push({ name: label, value: 1, total: (p.quantity || 0) * (p.unit_price || 0) });
    }
    return acc;
  }, []);

  if (categoryData.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200/60 p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-4">Por Categoria</h3>
        <div className="flex items-center justify-center py-12 text-sm text-slate-400">
          Nenhum produto cadastrado
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-200/60 p-6">
      <h3 className="text-lg font-semibold text-slate-800 mb-4">Por Categoria</h3>
      <div className="flex flex-col md:flex-row items-center gap-4">
        <div className="w-48 h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
                stroke="none"
              >
                {categoryData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip
                formatter={(value, name) => [`${value} produto(s)`, name]}
                contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0", fontSize: "13px" }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex-1 space-y-2 w-full">
          {categoryData.map((item, index) => (
            <div key={item.name} className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                <span className="text-slate-600">{item.name}</span>
              </div>
              <span className="font-semibold text-slate-800">{item.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}