const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React from "react";
import { useQuery } from "@tanstack/react-query";

import { Sparkles } from "lucide-react";

function getDayOfYear() {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 0);
  const diff = now - start;
  const oneDay = 1000 * 60 * 60 * 24;
  return Math.floor(diff / oneDay);
}

export default function DailyPhrase() {
  const { data: phrases = [] } = useQuery({
    queryKey: ["phrases"],
    queryFn: () => db.entities.Phrase.list(),
  });

  const active = phrases.filter(p => p.active !== false);
  if (active.length === 0) return null;

  const dayIndex = getDayOfYear() % active.length;
  const phrase = active[dayIndex];

  return (
    <div className="bg-gradient-to-r from-[#1e3a5f] to-[#2d5a8e] rounded-2xl p-5 flex items-start gap-4 shadow-lg shadow-blue-900/20">
      <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center flex-shrink-0 mt-0.5">
        <Sparkles className="w-5 h-5 text-yellow-300" />
      </div>
      <div>
        <p className="text-xs font-semibold text-blue-200 uppercase tracking-wider mb-1">Frase do Dia</p>
        <p className="text-white font-medium leading-relaxed">{phrase.text}</p>
      </div>
    </div>
  );
}