const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard, Package, ArrowLeftRight, Truck, ShoppingCart,
  ChevronRight, BarChart3, Users, X, Building2, Store, ClipboardList, Settings,
} from "lucide-react";
import { cn } from "@/lib/utils";
import Topbar from "@/components/layout/Topbar";
import RouteGuard from "@/components/auth/RouteGuard";
import { usePermissions } from "@/components/auth/usePermissions";

const ALL_NAV = [
  { name: "Dashboard", icon: LayoutDashboard, page: "Dashboard" },
  { name: "Produtos", icon: Package, page: "Products" },
  { name: "Movimentações", icon: ArrowLeftRight, page: "Movements" },
  { name: "Pedidos", icon: ShoppingCart, page: "Orders" },
  { name: "Fornecedores", icon: Truck, page: "Suppliers" },
  { name: "Relatórios", icon: BarChart3, page: "Reports" },
  { name: "Setores", icon: Building2, page: "Sectors" },
  { name: "Lojas", icon: Store, page: "Stores" },
  { name: "Área do Funcionário", icon: ClipboardList, page: "StockCount" },
  { name: "Usuários", icon: Users, page: "Users", adminOnly: true },
  { name: "Configurações", icon: Settings, page: "Settings", adminOnly: true },
];

const LOGO_URL = "https://media.db.com/images/public/69ba0915910a22001f6bf92b/3cba5cae7_LOGOMORAISINSTITUICAO.png";

export default function Layout({ children, currentPageName }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem("theme") === "dark");
  const { isAdmin, canAccessPage } = usePermissions();

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add("dark");
      localStorage.setItem("theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("theme", "light");
    }
  }, [darkMode]);

  const visibleNav = ALL_NAV.filter(item => {
    if (item.adminOnly) return isAdmin;
    return canAccessPage(item.page);
  });

  return (
    <RouteGuard>
    <div className="min-h-screen bg-background transition-colors duration-300 flex flex-col">
      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-black/40 backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed top-0 left-0 z-50 h-full w-[260px]",
        "bg-card border-r border-border",
        "transition-transform duration-300 ease-in-out",
        "lg:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        {/* Logo */}
        <div className="p-4 flex items-center justify-between border-b border-border">
          <div className="flex items-center gap-3">
            <img src={LOGO_URL} alt="O Morais" className="w-12 h-12 rounded-xl object-cover" />
            <div>
              <h1 className="font-bold text-foreground text-base leading-tight">O MORAIS</h1>
              <p className="text-xs text-muted-foreground mt-0.5">Gestão de Estoque</p>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-1.5 rounded-lg hover:bg-muted"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        {/* Nav */}
        <nav className="mt-4 px-3 space-y-0.5 overflow-y-auto" style={{ maxHeight: "calc(100vh - 200px)" }}>
          {visibleNav.map((item) => {
            const isActive = currentPageName === item.page;
            return (
              <Link
                key={item.page}
                to={createPageUrl(item.page)}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-md"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                )}
              >
                <item.icon className={cn("w-5 h-5", isActive ? "text-primary-foreground" : "text-muted-foreground")} />
                <span>{item.name}</span>
                {isActive && <ChevronRight className="w-4 h-4 ml-auto opacity-60" />}
              </Link>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-border bg-card">
          <p className="text-xs text-center text-muted-foreground">© 2025 O MORAIS - Desde 2019</p>
        </div>
      </aside>

      {/* Main */}
      <div className="lg:ml-[260px] flex flex-col min-h-screen bg-background">
        <Topbar
          onMenuOpen={() => setSidebarOpen(true)}
          darkMode={darkMode}
          onToggleDark={() => setDarkMode(d => !d)}
        />
        <main className="flex-1 p-4 md:p-8 max-w-[1400px] mx-auto w-full">
          {children}
        </main>
        {/* Page Footer */}
        <footer className="border-t border-border bg-card px-6 py-4 text-center">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} <strong>O MORAIS</strong> — Sistema de Gestão de Estoque · Desde 2019
          </p>
        </footer>
      </div>
    </div>
    </RouteGuard>
  );
}